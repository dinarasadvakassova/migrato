import {simulation as scenes,quiz as questions,problems,actions,rentalClauses} from '../data/content.js';
import {el,t,tri,labels,button,note,sourceBox,taskList,setProgress} from './shared.js';

const words={
 fiction:tri('Учебная история: персонажи и ситуации вымышлены. Действия в игре не означают выполнение реальных процедур.','Оқу оқиғасы: кейіпкерлер мен жағдайлар ойдан шығарылған. Ойындағы әрекеттер нақты рәсімдердің орындалғанын білдірмейді.','Learning story: people and situations are fictional. In-game actions do not complete real procedures.'),decision:tri('Как вы поступите?','Қалай әрекет етесіз?','What will you do?'),retry:tri('Вернуться к выбору','Таңдауға оралу','Try another choice'),help:tri('Разобрать безопасный вариант','Қауіпсіз нұсқаны талдау','Review the safer choice'),helpText:tri('Сравните объяснение с источниками, затем выберите подходящее действие.','Түсіндірмені дереккөздермен салыстырып, тиісті әрекетті таңдаңыз.','Compare the explanation with the sources, then choose an appropriate action.'),good:tri('Подходящее решение','Тиісті шешім','Appropriate decision'),caution:tri('В этой ветке возникла проблема','Бұл тармақта мәселе туындады','This branch leads to a problem'),completed:tri('Путь завершён','Жол аяқталды','Journey completed'),learning:tri('Вы разобрали все этапы. Теперь можно составить собственный справочный маршрут и проверить реальные требования.','Барлық кезеңдерді қарастырдыңыз. Енді өз ақпараттық жоспарыңызды құрып, нақты талаптарды тексеруге болады.','You have reviewed every stage. Build your reference route next and verify the real requirements.'),route:tri('Перейти к маршруту','Жоспарға өту','Open my route'),firstTry:tri('Решений с первой попытки','Алғашқы әрекеттен дұрыс шешімдер','First-attempt decisions'),correct:tri('Верно','Дұрыс','Correct'),incorrect:tri('Неверно','Дұрыс емес','Incorrect'),quizEnd:tri('Результат теста','Тест нәтижесі','Quiz result'),review:tri('Темы для повторения','Қайталауға арналған тақырыптар','Topics to review'),allCorrect:tri('Все ответы верны. Вернитесь к источникам перед применением информации в жизни.','Барлық жауап дұрыс. Ақпаратты өмірде қолданар алдында дереккөздерді қайта тексеріңіз.','All answers are correct. Revisit the sources before applying this information in real life.'),answer:tri('Выберите один ответ. Объяснение появится сразу.','Бір жауапты таңдаңыз. Түсіндірме бірден көрсетіледі.','Choose one answer. An explanation appears immediately.'),issue:tri('С какой темой нужна помощь?','Қай тақырып бойынша көмек қажет?','What do you need help with?'),resetIssue:tri('Выбрать другую проблему','Басқа мәселені таңдау','Choose another problem'),reference:tri('Это справочная инструкция по готовому сценарию. Для индивидуального решения обратитесь в компетентный орган или к специалисту.','Бұл дайын сценарий бойынша ақпараттық нұсқаулық. Жеке шешім үшін құзыретті органға немесе маманға жүгініңіз.','This is reference information for a preset scenario. Contact the competent authority or a qualified professional for an individual decision.'),rental:tri('Проверьте учебный договор','Оқу шартын тексеріңіз','Review a sample rental agreement'),rentalIntro:tri('Это вымышленный договор. Отметьте условия, которые требуют уточнения или создают риск. Затем сравните с объяснениями.','Бұл ойдан шығарылған шарт. Нақтылауды қажет ететін немесе тәуекел туғызатын талаптарды белгілеңіз. Содан кейін түсіндірмелермен салыстырыңыз.','This agreement is fictional. Mark clauses that need clarification or create a risk, then compare your choices with the explanations.'),evaluate:tri('Проверить выбор','Таңдауды тексеру','Check my choices'),attention:tri('Требует внимания','Назар аударуды қажет етеді','Needs attention'),neutral:tri('В этом учебном примере явного риска не отмечено','Бұл оқу мысалында айқын тәуекел көрсетілмеген','No clear risk is flagged in this learning example'),matched:tri('Верно распознано','Дұрыс анықталды','Correctly identified'),rentalNote:tri('Отсутствие отмеченного риска не подтверждает действительность или безопасность настоящего договора.','Белгіленген тәуекелдің болмауы нақты шарттың жарамдылығын немесе қауіпсіздігін растамайды.','An unflagged clause does not confirm that a real agreement is valid or safe.')
};

export function simulation(ctx) {
 const s=ctx.state.simulation;
 ctx.container.append(note(ctx,words.fiction));
 if(s.index>=scenes.length){
  const first=scenes.filter((scene,i)=>{const attempts=s.history[scene.id]||[];return attempts.length&&scene.choices[attempts[0]]?.positive;}).length;
  ctx.container.append(el('section',{class:'result-box success'},el('h3',{},t(ctx,words.completed)),el('p',{},t(ctx,words.learning)),el('p',{},`${t(ctx,words.firstTry)}: ${first} / ${scenes.length}`)),el('div',{class:'tool-actions'},button(ctx,words.route,()=>ctx.openTool('route')),button(ctx,labels.restart,()=>{ctx.state.simulation={index:0,choices:{},history:{},help:false};ctx.save();ctx.render();})));
  setProgress(ctx,scenes.length,scenes.length);return;
 }
 const scene=scenes[s.index];if(!scene){ctx.container.append(note(ctx,words.completed));return;}
 const choiceIndex=s.choices[scene.id],choice=scene.choices[choiceIndex];
 ctx.container.append(el('h3',{},t(ctx,scene.title)),el('p',{class:'scenario-scene'},t(ctx,scene.scene)),el('h4',{},t(ctx,words.decision)));
 const choices=el('div',{class:'choice-list'});
 scene.choices.forEach((item,index)=>choices.append(button(ctx,item.text,()=>{s.choices[scene.id]=index;(s.history[scene.id]??=[]).push(index);s.help=false;ctx.save();ctx.render();ctx.announce(t(ctx,item.positive?words.good:words.caution));},{class:`option-button ${index===choiceIndex?'selected':''}`,disabled:choice!==undefined,'aria-pressed':index===choiceIndex})));
 ctx.container.append(choices);
 if(choice){
  const result=el('section',{class:`result-box ${choice.positive?'success':'warning'}`},el('h4',{},t(ctx,choice.positive?words.good:words.caution)),el('p',{},t(ctx,choice.feedback)),sourceBox(ctx,choice.sourceIds));
  if(choice.positive)result.append(button(ctx,s.index===scenes.length-1?words.completed:labels.next,()=>{s.index++;s.help=false;ctx.save();ctx.render();}));
  else {
   result.append(el('div',{class:'tool-actions'},button(ctx,words.retry,()=>{delete s.choices[scene.id];s.help=false;ctx.save();ctx.render();}),button(ctx,words.help,()=>{s.help=true;ctx.save();ctx.render();})));
   if(s.help){const safe=scene.choices.find(c=>c.positive);result.append(note(ctx,words.helpText),el('p',{},t(ctx,safe?.feedback)),sourceBox(ctx,safe?.sourceIds));}
  }
  ctx.container.append(result);
 }
 setProgress(ctx,s.index,scenes.length);
}

export function quiz(ctx) {
 const s=ctx.state.quiz;
 if(s.index>=questions.length){
  const wrong=questions.filter(q=>s.answers[q.id]!==q.correct),score=questions.length-wrong.length;
  ctx.container.append(el('section',{class:'result-box'},el('h3',{},t(ctx,words.quizEnd)),el('p',{class:'result-score'},`${score} / ${questions.length}`)));
  if(wrong.length){ctx.container.append(el('h4',{},t(ctx,words.review)),el('ul',{},wrong.map(q=>el('li',{},el('strong',{},t(ctx,q.topic)),el('p',{},t(ctx,q.explanation)),sourceBox(ctx,q.sourceIds)))));}else ctx.container.append(note(ctx,words.allCorrect));
  ctx.container.append(button(ctx,labels.restart,()=>{ctx.state.quiz={index:0,answers:{}};ctx.save();ctx.render();}));setProgress(ctx,questions.length,questions.length);return;
 }
 const q=questions[s.index];if(!q)return;
 const selected=s.answers[q.id],answered=Number.isInteger(selected);
 ctx.container.append(el('p',{class:'tool-eyebrow'},t(ctx,q.topic)),el('h3',{},t(ctx,q.question)),note(ctx,words.answer));
 ctx.container.append(el('div',{class:'choice-list'},q.options.map((option,index)=>button(ctx,option,()=>{s.answers[q.id]=index;ctx.save();ctx.render();ctx.announce(t(ctx,index===q.correct?words.correct:words.incorrect));},{disabled:answered,class:`quiz-option option-button ${answered&&index===q.correct?'correct':''} ${answered&&selected===index&&selected!==q.correct?'incorrect':''}`,'aria-pressed':selected===index}))));
 if(answered)ctx.container.append(el('section',{class:`result-box ${selected===q.correct?'success':'warning'}`},el('h4',{},t(ctx,selected===q.correct?words.correct:words.incorrect)),el('p',{},t(ctx,q.explanation)),sourceBox(ctx,q.sourceIds),button(ctx,s.index===questions.length-1?words.quizEnd:labels.next,()=>{s.index++;ctx.save();ctx.render();})));
 setProgress(ctx,s.index,questions.length);
}

export function navigator(ctx) {
 const s=ctx.state.navigator;
 ctx.container.append(note(ctx,words.reference));
 if(!s.problem){ctx.container.append(el('h3',{},t(ctx,words.issue)),el('div',{class:'choice-list'},problems.map(problem=>button(ctx,problem.title,()=>{s.problem=problem.id;s.option=null;ctx.save();ctx.render();},{class:'option-button'}))));return;}
 const problem=problems.find(p=>p.id===s.problem);if(!problem){s.problem=null;return ctx.render();}
 ctx.container.append(el('h3',{},t(ctx,problem.title)),el('p',{},t(ctx,problem.question)),el('div',{class:'choice-list'},problem.options.map((option,index)=>button(ctx,option.label,()=>{s.option=index;ctx.save();ctx.render();},{class:`option-button ${s.option===index?'selected':''}`,'aria-pressed':s.option===index}))));
 const selected=problem.options[s.option];
 if(selected)ctx.container.append(el('section',{class:'result-box'},el('h4',{},t(ctx,selected.title)),el('p',{},t(ctx,selected.body)),taskList(ctx,(selected.actionIds||[]).map(id=>actions.find(a=>a.id===id)).filter(Boolean)),sourceBox(ctx,selected.sourceIds)));
 ctx.container.append(button(ctx,words.resetIssue,()=>{s.problem=null;s.option=null;ctx.save();ctx.render();}));
}

export function rental(ctx) {
 const s=ctx.state.rental;
 ctx.container.append(el('h3',{},t(ctx,words.rental)),note(ctx,words.rentalIntro));
 const list=el('ol',{class:'rental-clauses'});
 rentalClauses.forEach((clause,index)=>{
  const checked=Boolean(s.marked[clause.id]);
  const item=el('li',{},el('label',{class:'task-row'},el('input',{id:`clause-${clause.id}`,type:'checkbox',checked,onchange:e=>{const wasEvaluated=s.evaluated;s.marked[clause.id]=e.target.checked;s.evaluated=false;ctx.save();if(wasEvaluated){ctx.render();document.getElementById(`clause-${clause.id}`)?.focus({preventScroll:true});}}}),el('span',{},el('strong',{},`${index+1}. `),t(ctx,clause.text))));
  if(s.evaluated)item.append(el('div',{class:`result-box ${checked===clause.needsAttention?'success':'warning'}`},el('strong',{},t(ctx,clause.needsAttention?words.attention:words.neutral)),el('p',{},t(ctx,clause.explanation)),sourceBox(ctx,clause.sourceIds)));
  list.append(item);
 });
 ctx.container.append(list,button(ctx,words.evaluate,()=>{s.evaluated=true;ctx.save();ctx.render();ctx.announce(t(ctx,words.matched));}),note(ctx,words.rentalNote));
 if(s.evaluated){const score=rentalClauses.filter(c=>Boolean(s.marked[c.id])===c.needsAttention).length;ctx.container.append(el('p',{class:'result-score'},`${t(ctx,words.matched)}: ${score} / ${rentalClauses.length}`));setProgress(ctx,score,rentalClauses.length);}
}
