import {content,pick,actions} from './data/content.js';
import {el,t,tri,labels,select,setProgress} from './modules/shared.js';
import {route,calendar,checklist} from './modules/planning.js';
import {simulation,quiz,navigator as problemNavigator,rental} from './modules/learning.js';
import {map,budget,phrases} from './modules/practical.js';

const storageKey='migrato-progress-v1';
const categories=new Set(['student','worker','remote','relocate']);
const tools={simulation,route,quiz,calendar,navigator:problemNavigator,map,checklist,budget,rental,phrases};
const titles={simulation:tri('Жизнь в Казахстане: симуляция','Қазақстандағы өмір: симуляция','Life in Kazakhstan: simulation'),route:tri('Мой маршрут','Менің жоспарым','My route'),quiz:tri('Проверьте знания','Біліміңізді тексеріңіз','Test your knowledge'),calendar:tri('Календарь действий','Іс-қимыл күнтізбесі','Action calendar'),navigator:tri('Навигатор по ситуациям','Жағдайлар навигаторы','Situation navigator'),map:tri('Карта полезных мест','Пайдалы орындар картасы','Useful places'),checklist:tri('Чек-лист адаптации','Бейімделу тізімі','Adaptation checklist'),budget:tri('Бюджет переезда','Көшу бюджеті','Moving budget'),rental:tri('Проверка учебного договора','Оқу шартын тексеру','Sample contract review'),phrases:tri('Конструктор обращений','Өтініш құрастыру','Request phrase builder')};
const descriptions={simulation:tri('Принимайте решения и сравнивайте их последствия с источниками.','Шешім қабылдап, салдарын дереккөздермен салыстырыңыз.','Make decisions and compare their consequences with the sources.'),route:tri('Выберите свою ситуацию и получите последовательность справочных шагов.','Жағдайыңызды таңдап, ақпараттық қадамдар ретін алыңыз.','Choose your situation and get an ordered reference checklist.'),quiz:tri('12 ситуаций с объяснениями и ссылками на нормы.','Түсіндірмелер мен нормаларға сілтемелері бар 12 жағдай.','12 situations with explanations and links to legal provisions.'),calendar:tri('Проверенный календарь и ваши плановые даты.','Тексерілген күнтізбе және жоспарланған күндеріңіз.','A verified calendar and your own target dates.'),navigator:tri('Готовые сценарии помогают найти следующий шаг.','Дайын сценарийлер келесі қадамды табуға көмектеседі.','Preset scenarios help you find your next step.'),map:tri('Организации в Астане, Алматы и Шымкенте.','Астана, Алматы және Шымкент қалаларындағы ұйымдар.','Organisations in Astana, Almaty and Shymkent.'),checklist:tri('Отмечайте реальные действия по мере выполнения.','Нақты әрекеттерді орындалуына қарай белгілеңіз.','Check off real actions as you complete them.'),budget:tri('Два варианта с вашими суммами в тенге.','Өзіңіздің теңгедегі сомаларыңыз бар екі нұсқа.','Two scenarios using your own amounts in tenge.'),rental:tri('Найдите условия, которые требуют внимания.','Назар аударуды қажет ететін талаптарды табыңыз.','Find clauses that need attention.'),phrases:tri('Подготовьте вопрос на русском, казахском или английском.','Сұрақты орыс, қазақ немесе ағылшын тілінде дайындаңыз.','Prepare a request in Russian, Kazakh or English.')};
const words={language:tri('Язык интерфейса','Интерфейс тілі','Interface language'),storageError:tri('Сохранение в браузере недоступно. Прогресс останется только до закрытия этой страницы.','Браузерде сақтау қолжетімсіз. Прогресс осы бет жабылғанша ғана сақталады.','Browser storage is unavailable. Progress will last only until this page is closed.'),restoredError:tri('Сохранённый прогресс не удалось прочитать. Начат новый сеанс.','Сақталған прогресті оқу мүмкін болмады. Жаңа сеанс басталды.','Saved progress could not be read. A new session was started.'),progress:tri('Выполнено задач','Орындалған міндеттер','Tasks completed'),error:tri('Не удалось открыть инструмент. Закройте его и попробуйте снова.','Құралды ашу мүмкін болмады. Оны жауып, қайталап көріңіз.','The tool could not be opened. Close it and try again.'),reset:tri('Сбросить локальный прогресс? Все отметки и ответы в этом браузере будут удалены.','Жергілікті прогресті қалпына келтіру керек пе? Осы браузердегі белгілер мен жауаптар жойылады.','Reset local progress? All checkmarks and answers in this browser will be cleared.')};
function defaults(){return {version:1,lang:'ru',category:'',actionDone:{},route:{citizenship:'',purpose:'',days:'',stage:'before',ready:false},calendar:{citizenship:'',purpose:'',arrival:'',days:'',reminder:false,ready:false},simulation:{index:0,choices:{},history:{},help:false},quiz:{index:0,answers:{}},navigator:{problem:null,option:null},map:{city:'all',type:'all',selected:null},rental:{marked:{},evaluated:false},budget:{scenarios:[{},{}]},phrases:{situation:'service',lang:'',selected:{}}};}
const isObj=x=>x&&typeof x==='object'&&!Array.isArray(x);
function safeRecord(value,type){const result={};if(!isObj(value))return result;for(const [key,v] of Object.entries(value)){if(key==='__proto__'||key==='constructor'||key==='prototype')continue;if(type==='boolean'&&typeof v==='boolean')result[key]=v;if(type==='integer'&&Number.isInteger(v)&&v>=0&&v<1000)result[key]=v;if(type==='history'&&Array.isArray(v))result[key]=v.filter(n=>Number.isInteger(n)&&n>=0&&n<10).slice(-100);}return result;}
function restore(raw){const state=defaults();if(!isObj(raw)||raw.version!==1)return state;
 if(['ru','kk','en'].includes(raw.lang))state.lang=raw.lang;if(categories.has(raw.category))state.category=raw.category;
 state.actionDone=safeRecord(raw.actionDone,'boolean');
 for(const section of ['route','calendar','navigator','map'])if(isObj(raw[section]))for(const key of Object.keys(state[section])){const v=raw[section][key];if(v===null||typeof v==='boolean'||typeof v==='number'&&Number.isFinite(v)||typeof v==='string'&&v.length<500)state[section][key]=v;}
 if(isObj(raw.simulation)){state.simulation.index=Math.max(0,Math.min(100,Number.isInteger(raw.simulation.index)?raw.simulation.index:0));state.simulation.choices=safeRecord(raw.simulation.choices,'integer');state.simulation.history=safeRecord(raw.simulation.history,'history');state.simulation.help=raw.simulation.help===true;}
 if(isObj(raw.quiz)){state.quiz.index=Math.max(0,Math.min(100,Number.isInteger(raw.quiz.index)?raw.quiz.index:0));state.quiz.answers=safeRecord(raw.quiz.answers,'integer');}
 if(isObj(raw.rental)){state.rental.marked=safeRecord(raw.rental.marked,'boolean');state.rental.evaluated=raw.rental.evaluated===true;}
 if(Array.isArray(raw.budget?.scenarios))for(let i=0;i<2;i++)if(isObj(raw.budget.scenarios[i]))for(const key of ['rent','utilities','food','transport','connection','other','deposit','oneoff']){const value=raw.budget.scenarios[i][key];if(typeof value==='string'&&value.length<100||typeof value==='number'&&Number.isFinite(value))state.budget.scenarios[i][key]=value;}
 if(isObj(raw.phrases)){if(['service','bank','medical','rental'].includes(raw.phrases.situation))state.phrases.situation=raw.phrases.situation;if(['ru','kk','en'].includes(raw.phrases.lang))state.phrases.lang=raw.phrases.lang;state.phrases.selected=safeRecord(raw.phrases.selected,'boolean');}
 return state;
}
let state=defaults(),storageAvailable=true,storageIssue=null;
try {const saved=localStorage.getItem(storageKey);if(saved)state=restore(JSON.parse(saved));}catch(error){storageIssue=error instanceof SyntaxError?'restoredError':'storageError';if(!(error instanceof SyntaxError))storageAvailable=false;}
let currentTool=null,previousFocus=null;
const dialog=document.getElementById('tool-dialog'),container=document.getElementById('tool-content'),progress=document.getElementById('tool-progress'),status=document.getElementById('tool-status');
function announce(message){if(status){status.textContent='';requestAnimationFrame(()=>{status.textContent=message;});}}
function storageMessage(){let n=document.getElementById('storage-status');if(!storageIssue){if(n)n.remove();return;}if(!n){n=el('p',{id:'storage-status',class:'storage-status',role:'status'});(document.querySelector('main')||document.body).prepend(n);}n.textContent=pick(words[storageIssue],state.lang);}
function save(){if(storageAvailable)try{localStorage.setItem(storageKey,JSON.stringify(state));}catch{storageAvailable=false;storageIssue='storageError';storageMessage();}updateProgress();}
function updateProgress(){const relevant=actions.filter(a=>!state.category||!a.categories?.length||a.categories.includes('all')||a.categories.includes(state.category));const done=relevant.filter(a=>state.actionDone[a.id]).length,total=relevant.length,percentage=total?Math.round(done/total*100):0;
 const bar=document.getElementById('overall-progress');if(bar){if(bar.tagName==='PROGRESS'){bar.max=total||1;bar.value=done;}else{bar.setAttribute('role','progressbar');bar.setAttribute('aria-valuemin','0');bar.setAttribute('aria-valuemax',String(total));bar.setAttribute('aria-valuenow',String(done));bar.style.setProperty('--progress',`${percentage}%`);}bar.setAttribute('aria-label',`${pick(words.progress,state.lang)}: ${done} / ${total}`);}
 const label=document.getElementById('overall-progress-label');if(label)label.textContent=`${done} / ${total}`;
 if(currentTool==='route'&&state.route.ready||currentTool==='checklist'&&state.category){setProgress(ctx(),done,total);}
 document.querySelectorAll('[data-category]').forEach(n=>n.setAttribute('aria-pressed',String(n.dataset.category===state.category)));
}
function translate(){document.documentElement.lang=state.lang;document.querySelectorAll('[data-i18n]').forEach(n=>{const key=n.dataset.i18n;if(content[state.lang]?.[key]!==undefined)n.textContent=pick(content[state.lang][key],state.lang);});
 for(const [attribute,dataKey] of [['placeholder','i18nPlaceholder'],['aria-label','i18nAria'],['title','i18nTitle']])document.querySelectorAll(`[data-${dataKey.replace(/[A-Z]/g,m=>'-'+m.toLowerCase())}]`).forEach(n=>{const value=content[state.lang]?.[n.dataset[dataKey]];if(value!==undefined)n.setAttribute(attribute,pick(value,state.lang));});
 document.querySelectorAll('#language-select').forEach(n=>{n.value=state.lang;});document.querySelectorAll('[data-lang]').forEach(n=>n.setAttribute('aria-pressed',String(n.dataset.lang===state.lang)));
 const title=content[state.lang]?.['meta.title'];if(title)document.title=pick(title,state.lang);
 updateProgress();storageMessage();
}
function setLanguage(value){if(!['ru','kk','en'].includes(value))return;const focusId=document.activeElement?.id;state.lang=value;save();translate();if(currentTool)render();if(focusId)document.getElementById(focusId)?.focus({preventScroll:true});}
function ctx(){return {get lang(){return state.lang;},get state(){return state;},container,progress,save,render,updateProgress,announce,openTool};}
function render(){if(!currentTool||!container)return;const context=ctx();container.replaceChildren();progress?.replaceChildren();if(progress)progress.hidden=true;if(status)status.textContent='';
 document.getElementById('tool-title').textContent=t(context,titles[currentTool]);const summary=document.getElementById('tool-summary');if(summary)summary.textContent=t(context,descriptions[currentTool]);
 container.append(select(context,'tool-language',words.language,[['ru',tri('Русский','Орысша','Russian')],['kk',tri('Қазақша','Қазақша','Kazakh')],['en',tri('English','Ағылшынша','English')]],state.lang,setLanguage));
 try{tools[currentTool](context);}catch(error){container.append(el('p',{class:'field-error',role:'alert'},t(context,words.error)));console.error('Migrato tool:',currentTool,error);}
}
function openTool(id){if(!tools[id]||!dialog)return;previousFocus=dialog.open?previousFocus:document.activeElement;currentTool=id;render();if(!dialog.open){if(typeof dialog.showModal==='function')dialog.showModal();else{dialog.setAttribute('open','');dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');}}document.body.classList.add('dialog-open');const title=document.getElementById('tool-title');if(title){title.tabIndex=-1;title.focus({preventScroll:true});}}
function closeTool(){if(dialog?.open&&typeof dialog.close==='function')dialog.close();else{dialog?.removeAttribute('open');finishClose();}}
function finishClose(){currentTool=null;document.body.classList.remove('dialog-open','printing-tool');if(previousFocus?.isConnected)previousFocus.focus({preventScroll:true});previousFocus=null;}
window.openTool=openTool;
document.addEventListener('click',event=>{
 const control=event.target.closest('button,a');if(!control)return;
 if(control.matches('a[href^="#"]'))control.closest('details.mobile-menu')?.removeAttribute('open');
 if(control.dataset.tool){event.preventDefault();openTool(control.dataset.tool);}
 else if(control.dataset.category&&categories.has(control.dataset.category)){state.category=control.dataset.category;state.route.ready=false;state.calendar.ready=false;save();openTool('route');}
 else if(control.dataset.lang)setLanguage(control.dataset.lang);
 else if(control.dataset.action==='close-tool'||control.hasAttribute('data-close-dialog'))closeTool();
 else if(control.dataset.action==='reset-progress'){if(window.confirm(pick(words.reset,state.lang))){const lang=state.lang;state=defaults();state.lang=lang;save();translate();if(currentTool)render();}}
 else if(control.dataset.action==='toggle-menu'){const menu=document.getElementById(control.getAttribute('aria-controls'));if(menu){const expanded=control.getAttribute('aria-expanded')==='true';control.setAttribute('aria-expanded',String(!expanded));menu.hidden=expanded;}}
});
document.getElementById('language-select')?.addEventListener('change',event=>setLanguage(event.target.value));
dialog?.addEventListener('close',finishClose);
dialog?.addEventListener('cancel',()=>{document.body.classList.remove('dialog-open');});
dialog?.addEventListener('click',event=>{if(event.target===dialog){const box=dialog.getBoundingClientRect();if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)closeTool();}});
translate();
