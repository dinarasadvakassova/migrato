import {places} from '../data/content.js';
import {el,t,tri,labels,button,note,select,focusTarget} from './shared.js';

// Projection reference: https://wiki.openstreetmap.org/wiki/Slippy_map_tilenames
// Tile policy: https://operations.osmfoundation.org/policies/tiles/

const TILE=256,MIN_ZOOM=2,MAX_ZOOM=18,MAX_LAT=85.0511287798066;
// A comfortable display extent, not a surveyed political boundary.
export const COUNTRY_VIEW={west:46.4,east:87.5,south:40.5,north:55.6};
export const cities={
 astana:{lat:51.18010,lon:71.44598,name:tri('Астана','Астана','Astana'),source:'https://www.geonames.org/1526273/astana.html'},
 almaty:{lat:43.25249,lon:76.91150,name:tri('Алматы','Алматы','Almaty'),source:'https://www.geonames.org/1526384/almaty.html'},
 shymkent:{lat:42.30988,lon:69.60042,name:tri('Шымкент','Шымкент','Shymkent'),source:'https://www.geonames.org/1518980/shymkent.html'}
};
const words={
 city:tri('Город','Қала','City'),type:tri('Тип организации','Ұйым түрі','Organisation type'),
 service:tri('ЦОН и государственные услуги','ХҚКО және мемлекеттік қызметтер','Public services'),migration:tri('Миграционная служба','Көші-қон қызметі','Migration service'),bank:tri('Банки','Банктер','Banks'),medical:tri('Медицинские организации','Медициналық ұйымдар','Healthcare providers'),
 overview:tri('Маркеры обозначают обзорные координаты городов, а не офисы. Точные проверенные адреса указаны в списке. Перед визитом уточните приём по официальной ссылке.','Маркерлер кеңселерді емес, қалалардың шолу координаттарын көрсетеді. Нақты тексерілген мекенжайлар тізімде берілген. Бармас бұрын қабылдауды ресми сілтемеден нақтылаңыз.','Markers show overview city coordinates, not offices. Exact checked addresses are in the list. Confirm reception through the official link before visiting.'),
 viewport:tri('Географическая карта Казахстана','Қазақстанның географиялық картасы','Geographic map of Kazakhstan'),
 help:tri('Перетаскивайте карту мышью; используйте кнопки направлений или стрелки клавиатуры при фокусе на карте. Масштаб: +/− или Ctrl + колесо. Обычное колесо прокручивает страницу. На телефоне вертикальное движение прокручивает страницу.','Картаны тінтуірмен жылжытыңыз; бағыт батырмаларын немесе карта фокуста болғанда пернетақта көрсеткілерін қолданыңыз. Масштаб: +/− немесе Ctrl + дөңгелек. Қалыпты дөңгелек бетті айналдырады. Телефонда тік қозғалыс бетті айналдырады.','Drag with a mouse, use direction buttons, or use arrow keys when the map has focus. Zoom with +/− or Ctrl + wheel. Normal scrolling moves the page. On phones, vertical movement scrolls the page.'),
 zoomIn:tri('Увеличить карту','Картаны үлкейту','Zoom in'),zoomOut:tri('Уменьшить карту','Картаны кішірейту','Zoom out'),country:tri('Весь Казахстан','Бүкіл Қазақстан','All Kazakhstan'),
 north:tri('На север','Солтүстікке','Pan north'),south:tri('На юг','Оңтүстікке','Pan south'),west:tri('На запад','Батысқа','Pan west'),east:tri('На восток','Шығысқа','Pan east'),
 list:tri('К списку адресов','Мекенжайлар тізіміне','Go to address list'),listTitle:tri('Проверенные адреса','Тексерілген мекенжайлар','Checked addresses'),
 loading:tri('Загружается видимая часть карты. Адреса уже доступны в списке.','Картаның көрінетін бөлігі жүктелуде. Мекенжайлар тізімде қолжетімді.','Loading the visible map area. Addresses are already available in the list.'),
 ready:tri('Карта загружена. Маркеры показывают города.','Карта жүктелді. Маркерлер қалаларды көрсетеді.','Map loaded. Markers show cities.'),
 error:tri('Часть подложки недоступна. Используйте список адресов или внешнюю карту OpenStreetMap. Автоматические повторные запросы не выполняются.','Карта негізінің бір бөлігі қолжетімсіз. Мекенжайлар тізімін немесе сыртқы OpenStreetMap картасын қолданыңыз. Автоматты қайталап сұраулар орындалмайды.','Some map tiles are unavailable. Use the address list or the external OpenStreetMap map. Failed requests are not retried automatically.'),
 offline:tri('Нет подключения к сети. Детальная подложка не загружается; проверенные адреса остаются доступны.','Желіге қосылу жоқ. Егжей-тегжейлі негіз жүктелмейді; тексерілген мекенжайлар қолжетімді.','No network connection. The detailed basemap cannot load; checked addresses remain available.'),
 file:tri('Локальный файл: запросы тайлов отключены. Для детальной подложки откройте опубликованную HTTP(S)-версию с интернетом. Здесь доступны координаты городов, список адресов и внешняя карта.','Жергілікті файл: тайл сұраулары өшірілген. Егжей-тегжейлі негіз үшін интернеті бар жарияланған HTTP(S) нұсқасын ашыңыз. Мұнда қала координаттары, мекенжайлар тізімі және сыртқы карта қолжетімді.','Local file: tile requests are disabled. Open the published HTTP(S) version with internet for the detailed basemap. City coordinates, addresses and an external map are available here.'),
 noresults:tri('По этим фильтрам организаций нет. Измените город или тип.','Бұл сүзгілер бойынша ұйым жоқ. Қаланы немесе түрін өзгертіңіз.','No organisations match these filters. Change the city or type.'),
 retry:tri('Повторить загрузку видимой области','Көрінетін аймақты қайта жүктеу','Retry the visible area'),external:tri('Открыть внешнюю карту OpenStreetMap','Сыртқы OpenStreetMap картасын ашу','Open external OpenStreetMap map'),
 fallback:tri('Обзор городских координат. Детальная подложка требует HTTP(S) и интернет.','Қала координаттарының шолуы. Егжей-тегжейлі негізге HTTP(S) пен интернет қажет.','City-coordinate overview. A detailed basemap requires HTTP(S) and internet.'),
 scale:tri('Масштаб','Масштаб','Zoom'),count:tri('Организаций','Ұйымдар','Organisations'),phone:tri('Телефон','Телефон','Phone'),official:tri('Официальная информация','Ресми ақпарат','Official information'),
 showCity:tri('Показать город на карте','Қаланы картадан көрсету','Show the city on the map'),selected:tri('Выбрано','Таңдалды','Selected'),coordinates:tri('Координаты городов','Қала координаттары','City coordinates'),
 pan:tri('Перемещение карты','Картаны жылжыту','Pan the map')
};
const viewStates=new WeakMap();
const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
function finite(value,name){const number=Number(value);if(!Number.isFinite(number))throw new TypeError(`${name} must be finite`);return number;}
function zoomValue(zoom){const z=finite(zoom,'zoom');if(!Number.isInteger(z)||z<0||z>22)throw new RangeError('zoom must be an integer from 0 to 22');return z;}
export function project(lat,lon,zoom){
 const z=zoomValue(zoom),latitude=clamp(finite(lat,'latitude'),-MAX_LAT,MAX_LAT)*Math.PI/180,longitude=clamp(finite(lon,'longitude'),-180,180),size=TILE*2**z;
 return {x:(longitude+180)/360*size,y:clamp((1-Math.asinh(Math.tan(latitude))/Math.PI)/2*size,0,size)};
}
export function unproject(x,y,zoom){
 const z=zoomValue(zoom),size=TILE*2**z,px=clamp(finite(x,'x'),0,size),py=clamp(finite(y,'y'),0,size);
 return {lat:Math.atan(Math.sinh(Math.PI*(1-2*py/size)))*180/Math.PI,lon:px/size*360-180};
}
export function fitCountry(width,height,padding=24){
 const w=Math.max(1,finite(width,'width')),h=Math.max(1,finite(height,'height')),p=Math.max(0,finite(padding,'padding'));
 const nw=project(COUNTRY_VIEW.north,COUNTRY_VIEW.west,0),se=project(COUNTRY_VIEW.south,COUNTRY_VIEW.east,0),availableW=Math.max(1,w-2*p),availableH=Math.max(1,h-2*p);
 const zoom=clamp(Math.floor(Math.log2(Math.min(availableW/(se.x-nw.x),availableH/(se.y-nw.y)))),MIN_ZOOM,MAX_ZOOM),center=unproject((nw.x+se.x)/2,(nw.y+se.y)/2,0);
 return {...center,zoom};
}
export function visibleTiles({lat,lon,zoom,width,height}){
 const z=zoomValue(zoom),w=finite(width,'width'),h=finite(height,'height');if(w<=0||h<=0)return [];
 const center=project(lat,lon,z),left=center.x-w/2,top=center.y-h/2,max=2**z-1,tiles=[];
 const firstX=Math.max(0,Math.floor(left/TILE)),lastX=Math.min(max,Math.ceil((left+w)/TILE)-1),firstY=Math.max(0,Math.floor(top/TILE)),lastY=Math.min(max,Math.ceil((top+h)/TILE)-1);
 for(let y=firstY;y<=lastY;y++)for(let x=firstX;x<=lastX;x++)tiles.push({z,x,y,left:x*TILE-left,top:y*TILE-top,key:`${z}/${x}/${y}`});
 return tiles;
}
function clampCamera(camera,width,height){
 const zoom=clamp(Math.round(camera.zoom),MIN_ZOOM,MAX_ZOOM),size=TILE*2**zoom,p=project(camera.lat,camera.lon,zoom),halfW=Math.min(width/2,size/2),halfH=Math.min(height/2,size/2);
 return {...unproject(clamp(p.x,halfW,size-halfW),clamp(p.y,halfH,size-halfH),zoom),zoom};
}
function httpDocument(){return /^https?:$/.test(globalThis.location?.protocol||document.location?.protocol||'');}
function online(){return globalThis.navigator?.onLine!==false;}
function tileURL(tile){return `https://tile.openstreetmap.org/${tile.z}/${tile.x}/${tile.y}.png`;}

export function map(ctx){
 const state=ctx.state.map,selectedCity=state.city==='all'?'all':cities[state.city]?state.city:cities[ctx.state.profile?.city]?ctx.state.profile.city:'all';
 let saved=viewStates.get(state);
 if(!saved){saved={camera:null,mode:'country',city:selectedCity,cache:new Map(),failed:new Set(),instance:null};viewStates.set(state,saved);}
 saved.instance?.dispose();
 if(saved.city!==selectedCity){saved.camera=null;saved.city=selectedCity;}
 state.city=selectedCity;state.type=['service','migration','bank','medical'].includes(state.type)?state.type:'all';
 if(!saved.camera&&cities[selectedCity])saved.camera={...cities[selectedCity],zoom:11};
 if(cities[selectedCity]&&saved.mode!=='manual')saved.mode='city';
 const root=el('section',{class:'geomap'}),filters=el('div',{class:'geomap-filters tool-grid'});
 const cityField=select(ctx,'map-city',words.city,[['all',labels.all],...Object.entries(cities).map(([id,city])=>[id,city.name])],state.city,value=>chooseCity(value));
 const typeField=select(ctx,'map-type',words.type,[['all',labels.all],...['service','migration','bank','medical'].map(id=>[id,words[id]])],state.type,value=>{state.type=value;state.selected=null;ctx.save();renderList();paint({load:false});});
 filters.append(cityField,typeField);
 const citySelect=cityField.querySelector('select'),typeSelect=typeField.querySelector('select');
 const status=el('p',{class:'geomap-status',role:'status','aria-live':'polite'}),help=note(ctx,words.help);help.id='geomap-help';
 const viewport=el('div',{class:'geomap-viewport',tabindex:'0',role:'region','aria-label':t(ctx,words.viewport),'aria-describedby':'geomap-help',style:'position:relative;overflow:hidden;min-height:440px;touch-action:pan-y pinch-zoom;user-select:none'});
 const tiles=el('div',{class:'geomap-tiles','aria-hidden':'true',style:'position:absolute;inset:0;pointer-events:none'}),markerLayer=el('div',{class:'geomap-markers',style:'position:absolute;inset:0;pointer-events:none'}),fallback=el('p',{class:'geomap-fallback'},t(ctx,words.fallback));
 viewport.append(tiles,fallback,markerLayer);
 const list=el('section',{class:'geomap-list',id:'geomap-address-list','aria-labelledby':'geomap-list-title'},el('h3',{id:'geomap-list-title',tabindex:'-1'},t(ctx,words.listTitle))),rows=el('div',{class:'geomap-places'});list.append(rows);
 const external=el('a',{target:'_blank',rel:'noopener noreferrer',class:'geomap-external'},t(ctx,words.external));
 const attribution=el('div',{class:'geomap-attribution'},el('a',{href:'https://www.openstreetmap.org/copyright',target:'_blank',rel:'noopener noreferrer'},'© OpenStreetMap contributors'),el('span',{},` · ${t(ctx,words.coordinates)}: `),Object.values(cities).map((city,index)=>[index?' · ':'',el('a',{href:city.source,target:'_blank',rel:'noopener noreferrer'},`GeoNames — ${t(ctx,city.name)}`)]));
 let disposed=false,width=0,height=0,pendingFrame=null,wheelTimer=null,drag=null,visible=[],ro=null,mo=null,filtered=[],suspended=false;
 const listeners=[];
 const listen=(node,type,handler,options)=>{node?.addEventListener?.(type,handler,options);listeners.push(()=>node?.removeEventListener?.(type,handler,options));};
 const controls=el('div',{class:'geomap-toolbar'}),panControls=el('div',{class:'geomap-pan-controls',role:'group','aria-label':t(ctx,words.pan)}),scale=el('span',{class:'geomap-scale'});
 const control=(label,text,fn)=>el('button',{type:'button',onclick:fn,class:'geomap-control',style:'min-width:44px;min-height:44px','aria-label':t(ctx,label),title:t(ctx,label)},text);
 const plus=control(words.zoomIn,'+',()=>zoomAt(saved.camera.zoom+1)),minus=control(words.zoomOut,'−',()=>zoomAt(saved.camera.zoom-1));
 const country=button(ctx,words.country,()=>chooseCity('all'),{class:'geomap-country',style:'min-height:44px'}),toList=button(ctx,words.list,()=>focusTarget(document.getElementById('geomap-list-title')),{class:'geomap-to-list',style:'min-height:44px'});
 panControls.append(control(words.north,'↑',()=>pan(0,-120)),control(words.west,'←',()=>pan(-120,0)),control(words.east,'→',()=>pan(120,0)),control(words.south,'↓',()=>pan(0,120)));
 const retry=button(ctx,words.retry,()=>{if(!httpDocument()||!online())return;for(const tile of visible){saved.failed.delete(tile.key);const entry=saved.cache.get(tile.key);if(entry?.status==='error'){entry.node.remove();saved.cache.delete(tile.key);}}paint({load:true});},{class:'geomap-retry',hidden:true});
 controls.append(plus,minus,country,scale,toList);
 root.append(filters,note(ctx,words.overview),help,el('div',{class:'geomap-layout'},el('div',{class:'geomap-pane'},controls,panControls,viewport,attribution,status,retry,external),list));ctx.container.append(root);
 const markers=Object.entries(cities).map(([id,city])=>{
  const node=button(ctx,city.name,()=>chooseCity(id),{class:'geomap-city-marker',style:'position:absolute;pointer-events:auto;min-height:44px;min-width:44px;transform:translate(-50%,-50%)','data-city':id});markerLayer.append(node);return {id,city,node};
 });
 function dispose(){
  if(disposed)return;disposed=true;ro?.disconnect();mo?.disconnect();listeners.splice(0).forEach(remove=>remove());
  if(pendingFrame!==null)globalThis.cancelAnimationFrame?.(pendingFrame);if(wheelTimer!==null)clearTimeout(wheelTimer);
  saved.cache.forEach(entry=>{if(entry.owner===controller)entry.owner=null;if(entry.node.parentNode===tiles)entry.node.remove();});drag=null;
 }
 const controller={dispose,updateStatus};saved.instance=controller;
 function measure(){
  if(disposed)return false;if(!viewport.isConnected){dispose();return false;}
  const rect=viewport.getBoundingClientRect(),w=Math.round(rect.width??rect.right-rect.left),h=Math.round(rect.height??rect.bottom-rect.top);
  if(w<=0||h<=0)return false;
  const changed=w!==width||h!==height;width=w;height=h;
  if(!saved.camera||saved.mode==='country'&&changed)saved.camera=fitCountry(width,height);
  saved.camera=clampCamera(saved.camera,width,height);return true;
 }
 function updateStatus(){
  if(disposed||!viewport.isConnected)return;
  const errors=visible.some(tile=>saved.failed.has(tile.key)),loading=visible.some(tile=>saved.cache.get(tile.key)?.status==='loading');
  const mode=!httpDocument()?'filemode':!online()?'offline':errors||suspended||!visible.length?'error':loading?'loading':'ready';
  root.dataset.state=mode;status.dataset.state=mode;
  const message=t(ctx,mode==='filemode'?words.file:words[mode]);const text=message+(filtered.length?'':` ${t(ctx,words.noresults)}`);if(status.textContent!==text)status.textContent=text;
  retry.hidden=mode!=='error';retry.disabled=!online()||!httpDocument();fallback.hidden=mode==='ready'||mode==='loading';
 }
 function positionEntry(entry){
  const center=project(saved.camera.lat,saved.camera.lon,saved.camera.zoom),ratio=2**(saved.camera.zoom-entry.tile.z);
  entry.node.style.left=`${entry.tile.x*TILE*ratio-center.x+width/2}px`;entry.node.style.top=`${entry.tile.y*TILE*ratio-center.y+height/2}px`;entry.node.style.width=`${TILE*ratio}px`;entry.node.style.height=`${TILE*ratio}px`;
 }
 function loadTiles(){
  if(!httpDocument()||!online()){suspended=!online();visible=[];tiles.replaceChildren();return;}suspended=false;
  visible=visibleTiles({...saved.camera,width,height});const keys=new Set(visible.map(tile=>tile.key));
  saved.cache.forEach((entry,key)=>{if(!keys.has(key)&&entry.node.parentNode===tiles){entry.node.remove();entry.owner=null;}});
  for(const tile of visible){
   let entry=saved.cache.get(tile.key);
   if(!entry&&saved.failed.has(tile.key))continue;
   if(!entry){
    const image=el('img',{class:'geomap-tile',alt:'',width:TILE,height:TILE,draggable:'false',decoding:'async',style:'position:absolute;max-width:none;user-select:none'});
    entry={node:image,tile,status:'loading',owner:controller};saved.cache.set(tile.key,entry);
    image.addEventListener('load',()=>{entry.status='loaded';image.classList.remove('is-error');entry.owner?.updateStatus();});
    image.addEventListener('error',()=>{entry.status='error';saved.failed.add(tile.key);image.classList.add('is-error');entry.owner?.updateStatus();});
    // No fetch options, cache bypass, custom Referer or offline prefetch: ordinary browser <img> caching.
    image.src=tileURL(tile);
   }
   entry.owner=controller;positionEntry(entry);if(entry.node.parentNode!==tiles)tiles.append(entry.node);
  }
  for(const [key,entry]of saved.cache){if(saved.cache.size<=72)break;if(!keys.has(key)){entry.node.remove();entry.owner=null;saved.cache.delete(key);}}
 }
 function paint({load=true}={}){
  if(!measure())return;
  if(load)loadTiles();else saved.cache.forEach(entry=>{if(entry.node.parentNode===tiles)positionEntry(entry);});
  const center=project(saved.camera.lat,saved.camera.lon,saved.camera.zoom),chosen=places.find(place=>place.id===state.selected)?.city||state.city;
  markers.forEach(({id,city,node})=>{const p=project(city.lat,city.lon,saved.camera.zoom),x=p.x-center.x+width/2,y=p.y-center.y+height/2,count=places.filter(place=>place.city===id&&(state.type==='all'||place.type===state.type)).length;node.style.left=`${x}px`;node.style.top=`${y}px`;node.hidden=x<-30||x>width+30||y<-30||y>height+30;node.textContent=`${t(ctx,city.name)} · ${count}`;node.classList.toggle('is-selected',chosen===id);node.setAttribute('aria-pressed',String(chosen===id));node.setAttribute('aria-label',`${t(ctx,city.name)}: ${t(ctx,words.count)} ${count}. ${t(ctx,words.showCity)}`);});
  plus.disabled=saved.camera.zoom>=MAX_ZOOM;minus.disabled=saved.camera.zoom<=MIN_ZOOM;scale.textContent=`${t(ctx,words.scale)} ${saved.camera.zoom}`;
  viewport.dataset.camera=JSON.stringify({lat:saved.camera.lat,lon:saved.camera.lon,zoom:saved.camera.zoom});external.href=`https://www.openstreetmap.org/#map=${saved.camera.zoom}/${saved.camera.lat.toFixed(5)}/${saved.camera.lon.toFixed(5)}`;
  updateStatus();
 }
 function renderList(){
  filtered=places.filter(place=>(state.city==='all'||place.city===state.city)&&(state.type==='all'||place.type===state.type));rows.replaceChildren();
  if(!filtered.length){rows.append(el('p',{class:'geomap-empty'},t(ctx,words.noresults)));return;}
  filtered.forEach(place=>{
   const card=el('article',{class:`geomap-place ${state.selected===place.id?'is-selected':''}`,'data-place':place.id},el('h4',{},t(ctx,place.name)),el('p',{class:'geomap-place-type'},`${t(ctx,cities[place.city]?.name)} · ${t(ctx,words[place.type])}`),el('p',{},t(ctx,place.address)),el('p',{},t(ctx,place.description)));
   if(place.phone)card.append(el('p',{},`${t(ctx,words.phone)}: `,el('a',{href:`tel:${place.phone.replace(/[^+\d]/g,'')}`},place.phone)));
   card.append(el('a',{href:place.url,target:'_blank',rel:'noopener noreferrer'},t(ctx,words.official)),el('small',{},`${t(ctx,labels.checked)}: ${place.checked}`),button(ctx,words.showCity,()=>{state.selected=place.id;ctx.save();rows.querySelectorAll('[data-place]').forEach(row=>row.classList.toggle('is-selected',row.dataset.place===place.id));saved.mode='manual';saved.camera={lat:cities[place.city].lat,lon:cities[place.city].lon,zoom:11};paint({load:true});},{class:'geomap-show-city',style:'min-height:44px','aria-label':`${t(ctx,words.showCity)}: ${t(ctx,place.name)}`}));rows.append(card);
  });
 }
 function chooseCity(value){
  if(!cities[value]&&value!=='all')return;state.city=value;state.selected=null;saved.city=value;citySelect.value=value;
  saved.mode=value==='all'?'country':'city';saved.camera=value==='all'?null:{lat:cities[value].lat,lon:cities[value].lon,zoom:11};ctx.save();renderList();paint({load:true});
 }
 function pan(dx,dy){
  if(!measure())return;const center=project(saved.camera.lat,saved.camera.lon,saved.camera.zoom);saved.camera={...unproject(center.x+dx,center.y+dy,saved.camera.zoom),zoom:saved.camera.zoom};saved.mode='manual';paint({load:true});
 }
 function zoomAt(value,anchor,load=true){
  if(!measure())return;const zoom=clamp(Math.round(value),MIN_ZOOM,MAX_ZOOM);if(zoom===saved.camera.zoom)return;
  const old=project(saved.camera.lat,saved.camera.lon,saved.camera.zoom),point=anchor||{x:width/2,y:height/2},ratio=2**(zoom-saved.camera.zoom);
  saved.camera={...unproject((old.x+point.x-width/2)*ratio-point.x+width/2,(old.y+point.y-height/2)*ratio-point.y+height/2,zoom),zoom};saved.mode='manual';paint({load});
 }
 listen(viewport,'keydown',event=>{
  if(event.target!==viewport||document.activeElement!==viewport)return;const command={ArrowLeft:()=>pan(-120,0),ArrowRight:()=>pan(120,0),ArrowUp:()=>pan(0,-120),ArrowDown:()=>pan(0,120),'+':()=>zoomAt(saved.camera.zoom+1),'=':()=>zoomAt(saved.camera.zoom+1),'-':()=>zoomAt(saved.camera.zoom-1),'_':()=>zoomAt(saved.camera.zoom-1),Home:()=>chooseCity('all')}[event.key];if(command){event.preventDefault();command();}
 });
 listen(viewport,'wheel',event=>{
  if(!event.ctrlKey)return;event.preventDefault();if(!measure())return;const rect=viewport.getBoundingClientRect();zoomAt(saved.camera.zoom+(event.deltaY<0?1:-1),{x:event.clientX-rect.left,y:event.clientY-rect.top},false);if(wheelTimer!==null)clearTimeout(wheelTimer);wheelTimer=setTimeout(()=>{wheelTimer=null;paint({load:true});},120);
 },{passive:false});
 listen(viewport,'pointerdown',event=>{
  if(event.button!==0||event.target.closest?.('button,a'))return;if(!measure())return;focusTarget(viewport,{preventScroll:true});const center=project(saved.camera.lat,saved.camera.lon,saved.camera.zoom);drag={id:event.pointerId,x:event.clientX,y:event.clientY,center,zoom:saved.camera.zoom,touch:event.pointerType==='touch',moved:false};viewport.setPointerCapture?.(event.pointerId);if(event.pointerType!=='touch')event.preventDefault();
 });
 listen(viewport,'pointermove',event=>{
  if(!drag||event.pointerId!==drag.id)return;const dx=event.clientX-drag.x,dy=event.clientY-drag.y;if(drag.touch&&Math.abs(dy)>Math.abs(dx))return;
  saved.camera={...unproject(drag.center.x-dx,drag.center.y-(drag.touch?0:dy),drag.zoom),zoom:drag.zoom};saved.mode='manual';drag.moved=true;paint({load:false});
 });
 const endDrag=event=>{if(!drag||event.pointerId!==drag.id)return;const moved=drag.moved;drag=null;if(moved)paint({load:true});};
 listen(viewport,'pointerup',endDrag);listen(viewport,'pointercancel',endDrag);
 listen(globalThis.window,'resize',()=>paint({load:true}));listen(globalThis.window,'offline',()=>{suspended=true;updateStatus();});listen(globalThis.window,'online',()=>updateStatus());
 const parentDialog=viewport.closest('dialog');listen(parentDialog,'close',dispose);
 if(typeof ResizeObserver==='function'){ro=new ResizeObserver(()=>{if(!viewport.isConnected)dispose();else paint({load:true});});ro.observe(viewport);}
 if(typeof MutationObserver==='function'){mo=new MutationObserver(()=>{if(!viewport.isConnected)dispose();});mo.observe(ctx.container,{childList:true});}
 renderList();pendingFrame=requestAnimationFrame(()=>{pendingFrame=null;paint({load:true});});
 return controller;
}
