#!/bin/zsh
cd -- "$(dirname -- "$0")"
exec node serve.mjs
