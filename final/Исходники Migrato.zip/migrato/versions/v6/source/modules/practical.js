import {places,phrasebook} from '../data/content.js';
import {el,t,tri,labels,button,note,field,select,numberValue} from './shared.js';

const words={
 city:tri('Город','Қала','City'),type:tri('Тип организации','Ұйым түрі','Organisation type'),astana:tri('Астана','Астана','Astana'),almaty:tri('Алматы','Алматы','Almaty'),shymkent:tri('Шымкент','Шымкент','Shymkent'),service:tri('ЦОН и государственные услуги','ХҚКО және мемлекеттік қызметтер','Public services'),migration:tri('Миграционная служба','Көші-қон қызметі','Migration service'),bank:tri('Банковские услуги','Банк қызметтері','Banking'),medical:tri('Медицинская помощь','Медициналық көмек','Healthcare'),map:tri('Схема Казахстана и выбранных организаций','Қазақстан мен таңдалған ұйымдар сызбасы','Schematic map of Kazakhstan and selected organisations'),mapNote:tri('Это обзорная схема, а не навигационная карта. Перед визитом уточните адрес, часы работы и перечень услуг по официальной ссылке.','Бұл шолу сызбасы, навигациялық карта емес. Бармас бұрын мекенжайды, жұмыс уақытын және қызметтерді ресми сілтеме арқылы нақтылаңыз.','This is a schematic overview, not a navigation map. Before visiting, confirm the address, opening hours and services using the official link.'),official:tri('Официальная информация','Ресми ақпарат','Official information'),noPlaces:tri('По выбранным фильтрам организаций нет. Измените фильтры.','Таңдалған сүзгілер бойынша ұйымдар жоқ. Сүзгілерді өзгертіңіз.','No organisations match these filters. Change the filters.'),phone:tri('Телефон','Телефон','Phone'),
 budgetIntro:tri('Сравните два собственных бюджета в тенге. Поля не содержат средних рыночных цен. Суммы можно оставить пустыми — они будут равны нулю.','Теңгемен екі жеке бюджетті салыстырыңыз. Өрістерде орташа нарықтық бағалар жоқ. Өрісті бос қалдыруға болады — ол нөлге тең болады.','Compare two budgets using your own amounts in tenge. No average market prices are provided. Empty amounts count as zero.'),a:tri('Вариант A','A нұсқасы','Scenario A'),b:tri('Вариант B','B нұсқасы','Scenario B'),rent:tri('Аренда в месяц, ₸','Айлық жалдау ақысы, ₸','Monthly rent, ₸'),utilities:tri('Коммунальные услуги в месяц, ₸','Айлық коммуналдық төлемдер, ₸','Monthly utilities, ₸'),food:tri('Питание в месяц, ₸','Айлық тамақ шығыны, ₸','Monthly food, ₸'),transport:tri('Транспорт в месяц, ₸','Айлық көлік шығыны, ₸','Monthly transport, ₸'),connection:tri('Связь в месяц, ₸','Айлық байланыс шығыны, ₸','Monthly phone and internet, ₸'),other:tri('Другие расходы в месяц, ₸','Басқа айлық шығындар, ₸','Other monthly costs, ₸'),deposit:tri('Возвратный депозит, ₸','Қайтарылатын депозит, ₸','Refundable deposit, ₸'),oneoff:tri('Другие разовые расходы, ₸','Басқа біржолғы шығындар, ₸','Other one-off costs, ₸'),monthly:tri('Ежемесячно','Ай сайын','Monthly total'),first:tri('Деньги на первый месяц','Бірінші айға қажет ақша','Cash needed for the first month'),formula:tri('Первый месяц = ежемесячные расходы + депозит + разовые расходы. Возвратный депозит включён в потребность в деньгах, но не считается невозвратной тратой.','Бірінші ай = айлық шығындар + депозит + біржолғы шығындар. Қайтарылатын депозит қажетті ақшаға қосылады, бірақ қайтарылмайтын шығын болып саналмайды.','First month = monthly costs + deposit + one-off costs. The refundable deposit is included in the cash needed, but is not treated as a non-refundable expense.'),amountError:tri('Введите конечную сумму от 0 до 1 000 000 000 000.','0 мен 1 000 000 000 000 арасындағы ақырлы соманы енгізіңіз.','Enter a finite amount from 0 to 1,000,000,000,000.'),fix:tri('Исправьте выделенные суммы для расчёта.','Есептеу үшін белгіленген сомаларды түзетіңіз.','Correct the highlighted amounts to calculate.'),difference:tri('Разница первого месяца B − A','Бірінші ай айырмасы B − A','First-month difference B − A'),
 phrasesIntro:tri('Соберите обращение из готовых фраз. Личные данные и свободный текст не нужны.','Дайын тіркестерден өтініш құрыңыз. Жеке деректер мен еркін мәтін қажет емес.','Build a request from ready-made phrases. No personal details or free text are needed.'),situation:tri('Ситуация','Жағдай','Situation'),outputLanguage:tri('Язык обращения','Өтініш тілі','Request language'),rental:tri('Аренда жилья','Баспана жалдау','Renting a home'),phrasesSelect:tri('Выберите фразы','Тіркестерді таңдаңыз','Choose phrases'),output:tri('Ваше обращение','Өтінішіңіз','Your request'),copy:tri('Копировать текст','Мәтінді көшіру','Copy text'),print:tri('Распечатать','Басып шығару','Print'),copied:tri('Текст скопирован.','Мәтін көшірілді.','Text copied.'),copyFallback:tri('Автоматическое копирование недоступно. Текст выделен: нажмите Ctrl+C или ⌘C, на телефоне выберите «Копировать».','Автоматты көшіру қолжетімсіз. Мәтін таңдалды: Ctrl+C немесе ⌘C басыңыз, телефонда «Көшіру» таңдаңыз.','Automatic copying is unavailable. The text is selected: press Ctrl+C or ⌘C, or choose Copy on your phone.'),emptyPhrase:tri('Отметьте хотя бы одну фразу.','Кемінде бір тіркесті белгілеңіз.','Select at least one phrase.'),phraseDisclaimer:tri('Готовые фразы помогают задать вопрос. Они не являются заявлением установленной формы или юридическим заключением.','Дайын тіркестер сұрақ қоюға көмектеседі. Олар белгіленген нысандағы өтініш немесе заң қорытындысы емес.','These phrases help you ask a question. They are not an official application form or legal opinion.')
};
const cities=['astana','almaty','shymkent'],types=['service','migration','bank','medical'];
function svgEl(tag,attrs={},text='') {const n=document.createElementNS('http://www.w3.org/2000/svg',tag);for(const [k,v]of Object.entries(attrs))n.setAttribute(k,v);n.textContent=text;return n;}
export function map(ctx) {
 const s=ctx.state.map;
 const chooseCity=city=>{s.city=city;s.selected=null;ctx.save();ctx.render();};
 const choosePlace=id=>{s.selected=id;ctx.save();ctx.render();const card=document.getElementById('place-'+id);card?.focus();card?.scrollIntoView({block:'nearest',behavior:'instant'});};
 ctx.container.append(el('div',{class:'tool-grid'},select(ctx,'map-city',words.city,[['all',labels.all],...cities.map(k=>[k,words[k]])],s.city||'all',chooseCity),select(ctx,'map-type',words.type,[['all',labels.all],...types.map(k=>[k,words[k]])],s.type||'all',v=>{s.type=v;s.selected=null;ctx.save();ctx.render();})),note(ctx,words.mapNote));
 const filtered=places.filter(p=>(s.city==='all'||!s.city||p.city===s.city)&&(s.type==='all'||!s.type||p.type===s.type));
 const svg=svgEl('svg',{viewBox:'0 0 1000 590',class:'map-canvas',role:'group','aria-label':t(ctx,words.map)});
 const addPoint=(x,y,label,aria,fn,selected=false)=>{
  const group=svgEl('g',{class:'map-point '+(selected?'selected':''),tabindex:'0',role:'button','aria-label':aria,'aria-pressed':String(selected)});
  group.append(svgEl('circle',{cx:x,cy:y,r:19}),svgEl('circle',{cx:x,cy:y,r:90,class:'map-hit',fill:'transparent'}),svgEl('text',{x,y:y+61,'text-anchor':'middle',class:'map-label'},label));
  group.addEventListener('click',fn);group.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();fn();}});svg.append(group);
 };
 if(s.city==='all'||!s.city){
  svg.append(svgEl('path',{class:'map-outline',d:'M65 205 L115 155 180 163 210 115 294 132 354 90 420 101 469 65 533 93 596 81 650 128 710 119 737 170 812 169 843 209 909 217 935 277 891 313 851 305 817 365 765 370 731 429 666 450 629 425 581 483 523 457 489 476 447 435 385 448 362 395 308 401 267 368 226 374 194 323 139 335 151 283 96 275 Z'}));
  for(const [city,x,y] of [['astana',650,175],['almaty',770,420],['shymkent',545,465]])addPoint(x,y,t(ctx,words[city]),t(ctx,words[city]),()=>chooseCity(city));
 }else{
  svg.append(svgEl('rect',{x:40,y:40,width:920,height:510,rx:45,class:'map-outline'}),svgEl('path',{d:'M80 295H920M500 80V520',fill:'none',stroke:'#fff','stroke-width':30}),svgEl('text',{x:70,y:90,class:'map-label'},t(ctx,words[s.city])));
  const short={service:tri('ЦОН','ХҚКО','Public services'),migration:tri('Миграция','Көші-қон','Migration'),bank:tri('Банк','Банк','Bank'),medical:tri('Медицина','Медицина','Healthcare')};
  filtered.forEach((p,i)=>{const x=290+(i%2)*420,y=195+Math.floor(i/2)*250;addPoint(x,y,t(ctx,short[p.type]),t(ctx,p.name),()=>choosePlace(p.id),s.selected===p.id);});
 }
 ctx.container.append(svg);
 if(!filtered.length){ctx.container.append(note(ctx,words.noPlaces));return;}
 const list=el('div',{class:'place-list'});
 filtered.forEach(place=>list.append(el('article',{id:'place-'+place.id,class:'place-card '+(s.selected===place.id?'selected':''),tabindex:-1},el('h3',{},t(ctx,place.name)),el('p',{},t(ctx,words[place.city])+' · '+t(ctx,words[place.type])),el('p',{},t(ctx,place.address)),place.phone?el('p',{},t(ctx,words.phone)+': ',el('a',{href:'tel:'+place.phone.replace(/[^+\d]/g,'')},place.phone)):null,el('p',{},t(ctx,place.description)),button(ctx,tri('Выбрать организацию','Ұйымды таңдау','Select organisation'),()=>choosePlace(place.id),{'aria-pressed':s.selected===place.id}),el('a',{href:place.url,target:'_blank',rel:'noopener noreferrer'},t(ctx,words.official)),el('small',{},t(ctx,labels.checked)+': '+place.checked))));
 ctx.container.append(list);
}

export function calculateBudget(values) {
 const monthlyKeys=['rent','utilities','food','transport','connection','other'];
 const normalized={};for(const key of [...monthlyKeys,'deposit','oneoff']){const n=numberValue(values[key]);if(n===null)return null;normalized[key]=n;}
 const monthly=monthlyKeys.reduce((sum,k)=>sum+normalized[k],0);
 return {monthly,first:monthly+normalized.deposit+normalized.oneoff};
}
export function budget(ctx) {
 const s=ctx.state.budget;
 ctx.container.append(note(ctx,words.budgetIntro));
 const form=el('form',{class:'tool-grid',onsubmit:e=>e.preventDefault()}),outputs=[],fields=[];
 const formatter=new Intl.NumberFormat(ctx.lang==='kk'?'kk-KZ':ctx.lang==='en'?'en-GB':'ru-RU',{style:'currency',currency:'KZT',maximumFractionDigits:2});
 function update(){
  fields.forEach(({control,key,index})=>{const invalid=numberValue(s.scenarios[index][key])===null;control.error.textContent=invalid?t(ctx,words.amountError):'';control.input.setAttribute('aria-invalid',String(invalid));});
  const totals=s.scenarios.map(calculateBudget);
  outputs.forEach((out,index)=>{const total=totals[index];out.replaceChildren(...(total?[el('div',{class:'metric'},el('span',{},t(ctx,words.monthly)),el('strong',{},formatter.format(total.monthly))),el('div',{class:'metric'},el('span',{},t(ctx,words.first)),el('strong',{},formatter.format(total.first)))]:[note(ctx,words.fix,'warning')]));});
  difference.textContent=totals.every(Boolean)?`${t(ctx,words.difference)}: ${formatter.format(totals[1].first-totals[0].first)}`:t(ctx,words.fix);
 }
 const difference=el('p',{class:'budget-difference','aria-live':'polite'});
 [0,1].forEach(index=>{
  const panel=el('fieldset',{class:'budget-scenario'},el('legend',{},t(ctx,index?words.b:words.a)));
  for(const key of ['rent','utilities','food','transport','connection','other','deposit','oneoff']){
   const control=field(ctx,`budget-${index}-${key}`,words[key],el('input',{type:'number',min:0,max:1e12,step:'any',inputmode:'decimal',value:s.scenarios[index][key]??'',oninput:e=>{s.scenarios[index][key]=e.target.validity.badInput?'NaN':e.target.value;ctx.save();update();}}));
   fields.push({control,key,index});panel.append(control.wrap);
  }
  const output=el('div',{class:'metric-grid','aria-live':'polite'});outputs.push(output);panel.append(output);form.append(panel);
 });
 ctx.container.append(form,difference,note(ctx,words.formula));update();
}

export function phrases(ctx) {
 const s=ctx.state.phrases;
 ctx.container.append(note(ctx,words.phrasesIntro));
 const available=Array.from(new Set(phrasebook.map(p=>p.situation)));
 if(!available.includes(s.situation))s.situation=available[0]||'service';
 ctx.container.append(el('div',{class:'tool-grid'},select(ctx,'phrase-situation',words.situation,available.map(k=>[k,words[k]||tri(k,k,k)]),s.situation,v=>{s.situation=v;ctx.save();ctx.render();}),select(ctx,'phrase-language',words.outputLanguage,[['ru',tri('Русский','Орысша','Russian')],['kk',tri('Қазақша','Қазақша','Kazakh')],['en',tri('English','Ағылшынша','English')]],s.lang||ctx.lang,v=>{s.lang=v;ctx.save();ctx.render();})));
 const groups=phrasebook.filter(g=>g.situation===s.situation),textLang=s.lang||ctx.lang;
 const output=el('textarea',{class:'phrase-output',rows:7,readonly:true,'aria-label':t(ctx,words.output)}),status=el('p',{class:'field-error','aria-live':'polite'});
 const choices=el('fieldset',{},el('legend',{},t(ctx,words.phrasesSelect)));
 function update(){output.value=groups.flatMap(g=>g.phrases).filter(p=>s.selected[p.id]).map(p=>typeof p.text==='string'?p.text:(p.text[textLang]||p.text.ru||'')).join('\n');status.textContent='';}
 groups.forEach(group=>{choices.append(el('h4',{},t(ctx,group.title)));group.phrases.forEach(phrase=>choices.append(el('label',{class:'task-row'},el('input',{type:'checkbox',checked:s.selected[phrase.id],onchange:e=>{s.selected[phrase.id]=e.target.checked;ctx.save();update();}}),typeof phrase.text==='string'?phrase.text:(phrase.text[textLang]||phrase.text.ru||''))));});
 const copy=button(ctx,words.copy,async()=>{
  if(!output.value){status.textContent=t(ctx,words.emptyPhrase);return;}
  try {if(!navigator.clipboard?.writeText)throw new Error('clipboard-unavailable');await navigator.clipboard.writeText(output.value);status.textContent=t(ctx,words.copied);ctx.announce(t(ctx,words.copied));}
  catch {output.focus();output.select();output.setSelectionRange(0,output.value.length);status.textContent=t(ctx,words.copyFallback);ctx.announce(t(ctx,words.copyFallback));}
 });
 const print=button(ctx,words.print,()=>{if(!output.value){status.textContent=t(ctx,words.emptyPhrase);return;}document.body.classList.add('printing-tool');window.addEventListener('afterprint',()=>document.body.classList.remove('printing-tool'),{once:true});window.print();});
 ctx.container.append(choices,el('h3',{},t(ctx,words.output)),output,status,el('div',{class:'tool-actions'},copy,print),note(ctx,words.phraseDisclaimer));update();
}
