import {BARYS_SVG} from './barys.js';
import {el,tri} from './shared.js';
import {pick} from '../data/content.js';
const texts={
 start:{title:tri('Начнём с вашего пути','Жолыңыздан бастайық','Let’s start your journey'),body:tri('Выберите статус, город и гражданство. Затем я помогу составить план переезда.','Санатыңызды, қалаңызды және азаматтығыңызды таңдаңыз. Содан кейін көшу жоспарын құруға көмектесемін.','Choose your status, city and citizenship. Then I can help you build a moving plan.'),action:tri('Составить план','Жоспар құру','Build my plan'),tool:'route',mood:'question'},
 documents:{title:tri('Документы по шагам','Құжаттар қадамдап','Documents, one step at a time'),body:tri('Здесь маршрут, календарь и разбор затруднений. Откройте нужный шаг: рядом будут источник и вопрос для обращения.','Мұнда жоспар, күнтізбе және қиындықтарды талдау бар. Қажетті қадамды ашыңыз: жанында дереккөз бен жүгінуге арналған сұрақ болады.','Find the route, calendar and situation navigator here. Open a step for its source and a question to ask the relevant office.'),action:tri('Открыть маршрут','Жоспарды ашу','Open my route'),tool:'route',mood:'explain'},
 life:{title:tri('Обустроимся без спешки','Асықпай орналасайық','Let’s settle in calmly'),body:tri('Здесь можно сравнить свои расходы, разобрать аренду, подготовить фразы и отметить выполненные дела.','Мұнда шығындарды салыстырып, жалдауды талдап, сөз тіркестерін дайындап, орындалған істерді белгілей аласыз.','Compare your costs, review rental terms, prepare phrases and mark completed tasks here.'),action:tri('Открыть чек-лист','Тізімді ашу','Open my checklist'),tool:'checklist',mood:'thinking'},
 faq:{title:tri('Найдём понятный ответ','Түсінікті жауап табайық','Let’s find a clear answer'),body:tri('В FAQ собраны частые вопросы с шагами, официальными источниками и адресатом. Введите тему и раскройте подходящий ответ.','FAQ бөлімінде қадамдар, ресми дереккөздер және жауапты ұйымдар бар. Тақырыпты енгізіп, сәйкес жауапты ашыңыз.','FAQ answers include steps, official sources and who to contact. Search a topic and open the matching answer.'),action:tri('Найти ответ','Жауап табу','Find an answer'),mood:'explain'},
 cities:{title:tri('Выберем нужную организацию','Қажетті ұйымды таңдайық','Let’s find the right organisation'),body:tri('Выберите город и тип организации. Проверьте адрес, источник и вопрос, с которым стоит обратиться.','Қала мен ұйым түрін таңдаңыз. Мекенжайды, дереккөзді және қоятын сұрақты тексеріңіз.','Choose a city and organisation type. Check the address, source and what to ask when contacting them.'),action:tri('Открыть карту','Картаны ашу','Open the map'),tool:'map',mood:'explain'}
};
let instance;
function reducedMotion(){return document.documentElement.dataset.motion==='paused'||globalThis.matchMedia?.('(prefers-reduced-motion: reduce)').matches;}
function motionButton(lang){
 const paused=document.documentElement.dataset.motion==='paused';
 const on=tri('Пауза анимации','Анимацияны тоқтату','Pause animation'),off=tri('Включить анимацию','Анимацияны қосу','Resume animation');
 const button=el('button',{type:'button',class:'guide-motion','aria-pressed':String(paused)},pick(paused?off:on,lang));
 button.addEventListener('click',()=>{const next=document.documentElement.dataset.motion!=='paused';document.documentElement.dataset.motion=next?'paused':'on';try{localStorage.setItem('migrato-motion',next?'paused':'on');}catch{}refreshSiteGuide();instance?.controls.querySelector('.guide-motion')?.focus({preventScroll:true});});
 return button;
}
export function mountSiteGuide({getState,openTool}){
 if(instance)return instance;
 const host=el('aside',{id:'site-guide',class:'site-guide','aria-label':'Динмухамед'});
 const toggle=el('button',{type:'button',class:'site-guide-toggle','aria-controls':'site-guide-bubble','aria-expanded':'false'});
 const character=el('span',{class:'barys-character barys--question','aria-hidden':'true'});character.innerHTML=BARYS_SVG;
 toggle.append(character);
 const bubble=el('section',{id:'site-guide-bubble',class:'site-guide-bubble',hidden:true});
 const close=el('button',{type:'button',class:'guide-close'},'×');
 const name=el('p',{class:'barys-name'}),title=el('h3'),body=el('p'),action=el('button',{type:'button',class:'button button-primary'});
 const controls=el('div',{class:'guide-secondary'});
 bubble.append(close,name,title,body,action,controls);host.append(toggle,bubble);document.body.append(host);
 instance={host,toggle,character,bubble,close,name,title,body,action,controls,getState,openTool,current:'start'};
 toggle.addEventListener('click',()=>{bubble.hidden=!bubble.hidden;toggle.setAttribute('aria-expanded',String(!bubble.hidden));});
 close.addEventListener('click',()=>{bubble.hidden=true;toggle.setAttribute('aria-expanded','false');toggle.focus();});
 action.addEventListener('click',()=>{
  const state=getState(),tip=texts[instance.current]||texts.start;
  if(instance.current==='faq'){document.getElementById('faq-search')?.focus();document.getElementById('faq')?.scrollIntoView({block:'start',behavior:reducedMotion()?'instant':'smooth'});}
  else if(!state.profile?.ready){document.getElementById('profile-panel')?.scrollIntoView({block:'center',behavior:reducedMotion()?'instant':'smooth'});document.getElementById('onboard-category')?.focus({preventScroll:true});}
  else openTool(tip.tool);
  bubble.hidden=true;toggle.setAttribute('aria-expanded','false');
 });
 const sections=[...document.querySelectorAll('main > section')];
 const update=()=>{const y=Math.min(innerHeight*.35,300);const section=sections.find(node=>{const box=node.getBoundingClientRect();return box.top<=y&&box.bottom>y;});if(section&&texts[section.id]&&instance.current!==section.id){instance.current=section.id;refreshSiteGuide();}};
 if(typeof IntersectionObserver!=='undefined'){const observer=new IntersectionObserver(update,{rootMargin:'-20% 0px -55% 0px',threshold:[0,.1,.5,1]});sections.forEach(section=>observer.observe(section));}
 let ticking=false;window.addEventListener('scroll',()=>{if(!ticking){ticking=true;requestAnimationFrame(()=>{ticking=false;update();});}},{passive:true});
 window.addEventListener('hashchange',update);refreshSiteGuide();update();return instance;
}
export function refreshSiteGuide(){
 if(!instance)return;
 const i=instance,state=i.getState(),lang=state.lang,tip=texts[i.current]||texts.start;
 i.host.setAttribute('aria-label',pick(tri('Динмухамед — путеводитель','Динмухамед — жолсерік','Dinmukhamed — guide'),lang));
 i.name.textContent=pick(tri('Динмухамед · ваш путеводитель','Динмухамед · жолсерігіңіз','Dinmukhamed · your guide'),lang);
 i.title.textContent=pick(tip.title,lang);i.body.textContent=pick(tip.body,lang);i.action.textContent=pick(tip.action,lang);
 i.toggle.setAttribute('aria-label',pick(tri('Подсказка Динмухамеда: ','Динмухамедтің кеңесі: ','Dinmukhamed’s hint: '),lang)+pick(tip.title,lang));
 i.close.setAttribute('aria-label',pick(tri('Свернуть подсказку','Кеңесті жинау','Collapse hint'),lang));
 i.character.className='barys-character barys--'+tip.mood;i.character.dataset.mood=tip.mood;
 i.controls.replaceChildren(motionButton(lang));
}

