import {places} from '../data/content.js';
import {cityNames} from '../data/personas.js';
import {el,t,tri,labels,note,select} from './shared.js';

const words={
 title:tri('Больницы в 2ГИС','Ауруханалар 2GIS-те','Hospitals on 2GIS'),
 intro:tri('Выберите город и откройте больницу в 2ГИС. Там можно посмотреть вход, часы работы и построить маршрут.','Қаланы таңдап, аурухананы 2GIS-те ашыңыз. Кіреберісті, жұмыс уақытын қарап, бағыт құра аласыз.','Choose a city and open a hospital on 2GIS to check the entrance, opening hours and directions.'),
 city:tri('Город','Қала','City'),type:tri('Тип организации','Ұйым түрі','Organisation type'),
 medical:tri('Больницы — ссылки 2ГИС','Ауруханалар — 2GIS сілтемелері','Hospitals — 2GIS links'),service:tri('ЦОН и государственные услуги','ХҚКО және мемлекеттік қызметтер','Public services'),migration:tri('Миграционная служба','Көші-қон қызметі','Migration service'),bank:tri('Банки','Банктер','Banks'),
 open:tri('Открыть в 2ГИС','2GIS-те ашу','Open in 2GIS'),all:tri('Все больницы города в 2ГИС','Қаладағы барлық ауруханалар 2GIS-те','Find more hospitals on 2GIS'),
 official:tri('Официальные контакты','Ресми байланыстар','Official contacts'),
 note:tri('Ссылка открывает поиск по названию и адресу в 2ГИС в новой вкладке. Условия приёма, оплату и страховку уточните у учреждения.','Сілтеме жаңа қойындыда 2GIS-тен атауы мен мекенжайы бойынша іздейді. Қабылдау, төлем және сақтандыру шарттарын мекемеден нақтылаңыз.','The link opens a 2GIS search by name and address in a new tab. Confirm appointments, payment and insurance with the provider.'),
 count:tri('Больниц в справочнике','Анықтамалықтағы ауруханалар','Hospitals in this directory')
};
// Public 2GIS search links, not API requests or unverified business IDs.
export function hospital2gisUrl(place){
 if(place?.type!=='medical'||!Object.hasOwn(cityNames,place.city))return null;
 return `https://2gis.kz/${place.city}/search/${encodeURIComponent(`${place.name.ru} ${place.address.ru}`)}`;
}
export function medicalCard(ctx,place){
 const card=el('article',{class:'medical-link-card','data-hospital':place.id},el('p',{class:'eyebrow'},t(ctx,cityNames[place.city])),el('h4',{},t(ctx,place.name)),el('p',{class:'medical-address'},t(ctx,place.address)),el('p',{},t(ctx,place.description)));
 if(place.phone)card.append(el('a',{class:'medical-phone',href:`tel:${place.phone.replace(/[^+\d]/g,'')}`},place.phone));
 card.append(el('a',{class:'button button--primary medical-2gis-link',href:hospital2gisUrl(place),target:'_blank',rel:'noopener noreferrer'},t(ctx,words.open),el('span',{'aria-hidden':'true'},' ↗')),
 el('a',{class:'medical-official',href:place.url,target:'_blank',rel:'noopener noreferrer'},t(ctx,words.official)),el('small',{class:'check-date'},`${t(ctx,labels.checked)}: ${place.checked}`));return card;
}
export function medicalLinks(ctx){
 const state=ctx.state.map;state.city=state.city==='all'||Object.hasOwn(cityNames,state.city)?state.city:'all';
 const root=el('section',{class:'medical-links'},el('h3',{},t(ctx,words.title)),note(ctx,words.intro));
 const filters=el('div',{class:'tool-grid'},select(ctx,'map-city',words.city,[['all',labels.all],...Object.entries(cityNames)],state.city,value=>{state.city=value;state.selected=null;ctx.save();renderCards();}),select(ctx,'map-type',words.type,[['all',labels.all],...['service','migration','bank','medical'].map(id=>[id,words[id]])],'medical',value=>{state.type=value;state.selected=null;ctx.save();ctx.render();}));
 const count=el('p',{class:'medical-links-count',role:'status','aria-live':'polite'}),cards=el('div',{class:'medical-links-grid'}),more=el('div',{class:'medical-city-links'});
 function renderCards(){
  const filtered=places.filter(place=>place.type==='medical'&&(state.city==='all'||place.city===state.city));
  count.textContent=`${t(ctx,words.count)}: ${filtered.length}`;cards.replaceChildren(...filtered.map(place=>medicalCard(ctx,place)));
  const cities=state.city==='all'?Object.keys(cityNames):[state.city];more.replaceChildren(...cities.map(city=>el('a',{class:'medical-city-link',href:`https://2gis.kz/${city}/search/${encodeURIComponent('Больницы')}`,target:'_blank',rel:'noopener noreferrer'},`${t(ctx,words.all)} · ${t(ctx,cityNames[city])} ↗`)));
 }
 root.append(filters,count,cards,more,note(ctx,words.note));ctx.container.append(root);renderCards();
}
