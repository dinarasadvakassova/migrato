# Barys visibility fix, 2026-11-13

Cause: the mascot was fixed, but its advice was reparented into section flow and scrolled off screen.

Current v18 SHA256: e88483b78b0b025018b19e7d5d4cd8496852e64dc26d123db4664692b6e1c7ef. Local commit bd201fb. Not pushed: the user previously chose manual push.

- npm test: 29/29 PASS; guide visibility, dismissal, no scroll jump, Escape, mobile input, viewport and focus regressions
- qa/release-current-dom.mjs --bundle: PASS in lightweight DOM; 5 sections and 10 tools in RU/KK/EN; not browser layout QA
- design_critic: fixed mascot/advice pairing accepted; keyboard, Escape and unchanged aria-live recommendations implemented
- project_tester: repeated tests, found resize-focus P2, confirmed its correction; no further regressions found in reviewed code
- Chrome v17: actual screenshot shows advice above the corner mascot on desktop; full native navigation and keyboard checks incomplete due to unreliable UI automation

Historical v16/v17 are preserved. Prompt and rationale: docs/PROMPTS.md P039. Word documents, delivery archives and Netlify deployment were not updated by this fix. Git commit contains only app.js, guide.css, site-guide.js and the test.
