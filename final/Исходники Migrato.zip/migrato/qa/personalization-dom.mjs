import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import vm from 'node:vm';
process.chdir(path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../..'));
let document;
const modalCalls=[],caughtErrors=[],originalConsoleError=console.error;
const animationCalls=[],mutationObservers=[];
console.error=(...args)=>{caughtErrors.push(args);originalConsoleError(...args.map(arg=>arg instanceof Error?`${arg.name}: ${arg.message}`:arg));};
const nativeSetTimeout=globalThis.setTimeout,nativeClearTimeout=globalThis.clearTimeout;
let timerNow=0,timerId=0;const timers=new Map();
globalThis.setTimeout=(fn,delay=0)=>{const id=++timerId;timers.set(id,{at:timerNow+Number(delay),fn});return id;};
globalThis.clearTimeout=id=>timers.delete(id);
function advance(ms){const until=timerNow+ms;for(;;){const next=[...timers].filter(([,task])=>task.at<=until).sort((a,b)=>a[1].at-b[1].at)[0];if(!next)break;const [id,task]=next;timerNow=task.at;timers.delete(id);task.fn();}timerNow=until;}
function mutated(record){for(const observer of mutationObservers){if(!observer.targets.some(({target,options})=>(record.target===target||options.subtree&&target.contains(record.target))&&options[record.type]&&(!options.attributeFilter||options.attributeFilter.includes(record.attributeName))))continue;observer.records.push(record);if(!observer.queued){observer.queued=true;queueMicrotask(()=>{observer.queued=false;const records=observer.records.splice(0);if(records.length&&observer.targets.length)observer.callback(records,observer);});}}}
const camel=s=>s.replace(/-([a-z])/g,(_,v)=>v.toUpperCase());
function simple(node,selector){
 if(!node?.tagName||node.tagName.startsWith('#'))return false;
 const attributeFree=selector.replace(/\[[^\]]*\]/g,'');
 const tag=attributeFree.match(/^[a-z][\w-]*/i)?.[0];if(tag&&node.tagName!==tag.toUpperCase())return false;
 for(const id of attributeFree.matchAll(/#([\w-]+)/g))if(node.id!==id[1])return false;
 for(const c of attributeFree.matchAll(/\.([\w-]+)/g))if(!node.className.split(/\s+/).includes(c[1]))return false;
 for(const a of selector.matchAll(/\[([\w-]+)(?:(\^?=)["']?([^"'\]]*)["']?)?\]/g)){
  const value=node.getAttribute(a[1]);if(value===null)return false;
  if(a[2]==='='&&value!==a[3])return false;
  if(a[2]==='^='&&!value.startsWith(a[3]))return false;
 }
 return true;
}
function match(node,selector){
 const direct=selector.lastIndexOf(' > ');if(direct>=0)return simple(node,selector.slice(direct+3))&&match(node.parentNode,selector.slice(0,direct));
 const space=selector.lastIndexOf(' ');if(space>=0){if(!simple(node,selector.slice(space+1)))return false;for(let p=node.parentNode;p;p=p.parentNode)if(match(p,selector.slice(0,space)))return true;return false;}
 return simple(node,selector);
}
class FakeNode{
 constructor(tag){this.tagName=tag.toUpperCase();this.childNodes=[];this.parentNode=null;this.attrs={};this.dataset={};this.events={};this.style={setProperty(k,v){this[k]=String(v);},getPropertyValue(k){return this[k]||'';}};this._text='';this.disabled=false;this.classList={add:(...xs)=>{this.className=[...new Set([...this.className.split(/\s+/),...xs])].filter(Boolean).join(' ');},remove:(...xs)=>{this.className=this.className.split(/\s+/).filter(x=>!xs.includes(x)).join(' ');}};}
 get id(){return this.attrs.id||'';}set id(v){this.setAttribute('id',v);}
 get className(){return this.attrs.class||'';}set className(v){this.setAttribute('class',v);}
 get tabIndex(){return Number(this.attrs.tabindex??-1);}set tabIndex(v){this.setAttribute('tabindex',v);}
 get children(){return this.childNodes.filter(n=>!n.tagName.startsWith('#'));}
 get isConnected(){let p=this;while(p){if(p===document?.documentElement)return true;p=p.parentNode;}return false;}
 get textContent(){return this._text+this.childNodes.map(n=>n.textContent).join('');}set textContent(v){this.replaceChildren();this._text=String(v);}
 get value(){return this._value??this.attrs.value??'';}set value(v){this._value=String(v);}
 setAttribute(k,v){this.attrs[k]=String(v);if(k.startsWith('data-'))this.dataset[camel(k.slice(5))]=String(v);}
 getAttribute(k){return this.attrs[k]??null;}hasAttribute(k){return Object.hasOwn(this.attrs,k);}removeAttribute(k){delete this.attrs[k];}
 append(...nodes){for(let n of nodes){if(!(n instanceof FakeNode)){n=Object.assign(new FakeNode('#text'),{_text:String(n)});}if(n.parentNode)n.remove();n.parentNode=this;this.childNodes.push(n);}}
 prepend(n){this.append(n);this.childNodes.unshift(this.childNodes.pop());}
 replaceChildren(...nodes){for(const n of this.childNodes){if(n.contains(document?.activeElement))document.activeElement=document.body;n.parentNode=null;}this.childNodes=[];this._text='';this.append(...nodes);}
 remove(){const p=this.parentNode;if(!p)return;if(this.contains(document?.activeElement))document.activeElement=document.body;p.childNodes=p.childNodes.filter(n=>n!==this);this.parentNode=null;}
 contains(n){for(let p=n;p;p=p.parentNode)if(p===this)return true;return false;}
 matches(sel){return sel.split(',').some(s=>match(this,s.trim()));}
 closest(sel){for(let p=this;p;p=p.parentNode)if(p.matches?.(sel))return p;return null;}
 querySelectorAll(sel){const all=[];const walk=n=>{for(const c of n.childNodes||[]){if(c.matches(sel))all.push(c);walk(c);}};walk(this);return all;}
 querySelector(sel){return this.querySelectorAll(sel)[0]||null;}
 addEventListener(type,fn,options){const capture=options===true||Boolean(options?.capture);if(!(this.events[type]||[]).some(listener=>listener.fn===fn&&listener.capture===capture))(this.events[type]??=[]).push({fn,capture,once:Boolean(options?.once)});}
 removeEventListener(type,fn,options){const capture=options===true||Boolean(options?.capture);this.events[type]=(this.events[type]||[]).filter(listener=>listener.fn!==fn||listener.capture!==capture);}
 dispatchEvent(e){e.target??=this;e.preventDefault??=()=>{e.defaultPrevented=true;};const chain=[];for(let n=this;n;n=n.parentNode)chain.push(n);if(chain.includes(document.documentElement))chain.push(document);e.composedPath??=()=>chain.slice();const invoke=(n,capture)=>{e.currentTarget=n;for(const listener of [...n.events?.[e.type]||[]])if(listener.capture===capture){listener.fn(e);if(listener.once)n.removeEventListener(e.type,listener.fn,{capture});}};for(const n of chain.slice(1).reverse())invoke(n,true);invoke(this,true);invoke(this,false);if(e.bubbles!==false)for(const n of chain.slice(1))invoke(n,false);return !e.defaultPrevented;}
 click(){this.dispatchEvent({type:'click',bubbles:true});}
 focus(){if(this.isConnected&&!this.disabled)document.activeElement=this;}
 setSelectionRange(start,end,direction){this.selectionStart=start;this.selectionEnd=end;this.selectionDirection=direction;}
 showModal(){modalCalls.push(this);this.returnFocus=document.activeElement;this.open=true;}close(){this.open=false;if(this.returnFocus?.isConnected)this.returnFocus.focus();this.dispatchEvent({type:'close',bubbles:false});}
 getBoundingClientRect(){return this.rect||{left:0,top:0,right:1000,bottom:1000,width:1000,height:1000};}
 scrollIntoView(options){this.lastScrollIntoView=options;}
 animate(keyframes,options){let resolve,reject;const record={node:this,keyframes,options,playState:'running',finished:new Promise((a,b)=>{resolve=a;reject=b;})};const timer=setTimeout(()=>{record.playState='finished';resolve();},options.duration);record.cancel=()=>{clearTimeout(timer);record.playState='idle';record.cancelled=true;reject(new Error('Animation cancelled'));};animationCalls.push(record);return record;}
}
document={events:{},createElement:tag=>new FakeNode(tag),createTextNode:text=>Object.assign(new FakeNode('#text'),{_text:String(text)}),createDocumentFragment:()=>new FakeNode('#fragment'),addEventListener:FakeNode.prototype.addEventListener,removeEventListener:FakeNode.prototype.removeEventListener,getElementById(id){return this.querySelectorAll('[id]').find(n=>n.id===id)||null;},querySelectorAll(sel){return this.documentElement.querySelectorAll(sel);},querySelector(sel){return this.querySelectorAll(sel)[0]||null;}};
document.documentElement=new FakeNode('html');document.body=new FakeNode('body');document.documentElement.append(document.body);document.activeElement=document.body;
document.documentElement.dataset=new Proxy(document.documentElement.dataset,{set(target,key,value){target[key]=String(value);const name='data-'+String(key).replace(/[A-Z]/g,m=>'-'+m.toLowerCase());document.documentElement.attrs[name]=String(value);mutated({type:'attributes',target:document.documentElement,attributeName:name});return true;}});
globalThis.document=document;globalThis.Node=FakeNode;globalThis.innerHeight=900;
const reducedMedia={matches:false,listeners:new Set(),addEventListener(type,fn){if(type==='change')this.listeners.add(fn);},removeEventListener(type,fn){if(type==='change')this.listeners.delete(fn);}};
globalThis.matchMedia=()=>reducedMedia;
function setReduced(value){reducedMedia.matches=value;for(const listener of reducedMedia.listeners)listener({matches:value,media:'(prefers-reduced-motion: reduce)'});}
globalThis.MutationObserver=class{constructor(callback){this.callback=callback;this.targets=[];this.records=[];mutationObservers.push(this);}observe(target,options){this.targets.push({target,options});}disconnect(){this.targets=[];this.records=[];}takeRecords(){return this.records.splice(0);}};
globalThis.window={confirm:()=>true,innerHeight:900,events:{},addEventListener(type,fn){(this.events[type]??=[]).push(fn);},removeEventListener(type,fn){this.events[type]=(this.events[type]||[]).filter(listener=>listener!==fn);},dispatchEvent(event){for(const fn of this.events[event.type]||[])fn(event);}};
const resizeObservers=[];
globalThis.ResizeObserver=class{constructor(callback){this.callback=callback;this.targets=new Set();resizeObservers.push(this);}observe(node){this.targets.add(node);}disconnect(){this.targets.clear();}trigger(){if(this.targets.size)this.callback([...this.targets].map(target=>({target,contentRect:target.getBoundingClientRect()})),this);}};
globalThis.requestAnimationFrame=fn=>fn();globalThis.localStorage={data:new Map(),getItem(k){return this.data.get(k)||null;},setItem(k,v){this.data.set(k,v);}};
const add=(parent,tag,id,attrs={})=>{const n=new FakeNode(tag);if(id)n.id=id;for(const[k,v]of Object.entries(attrs))n.setAttribute(k,v);parent.append(n);return n;};
const main=add(document.body,'main');const language=add(document.body,'select','language-select');add(main,'progress','overall-progress');add(main,'span','overall-progress-label');
const launches={};for(const tool of ['simulation','quiz','navigator','route'])launches[tool]=add(main,'button',`launch-${tool}`,{'data-tool':tool});
const dialog=add(document.body,'dialog','tool-dialog');add(dialog,'h2','tool-title');add(dialog,'p','tool-summary');const close=add(dialog,'button','close',{'data-action':'close-tool'});add(dialog,'div','tool-progress');const content=add(dialog,'div','tool-content');add(dialog,'p','tool-status');
const port=add(dialog,'div','qa-tool-scrollport');port.className='tool-dialog-body';port.clientHeight=780;port.append(document.getElementById('tool-progress'),content,document.getElementById('tool-status'));
const cache=new Map();function moduleURL(file){const full=path.resolve(file);if(cache.has(full))return cache.get(full);let code=fs.readFileSync(full,'utf8');code=code.replace(/from\s+(['"])(\.[^'"]+)\1/g,(_,q,rel)=>`from '${moduleURL(path.resolve(path.dirname(full),rel))}'`);const url='data:text/javascript;base64,'+Buffer.from(code).toString('base64');cache.set(full,url);return url;}
const originalCreate=document.createElement;
document.createElement=tag=>{const node=originalCreate(tag);node.classList.toggle=(name,force)=>{const exists=node.className.split(/\s+/).includes(name);const on=force===undefined?!exists:force;node.classList[on?'add':'remove'](name);return on;};return node;};
document.createElementNS=(_ns,tag)=>document.createElement(tag);
Object.defineProperty(FakeNode.prototype,'open',{get(){return this.hasAttribute('open');},set(v){if(v)this.setAttribute('open','');else this.removeAttribute('open');}});
Object.defineProperty(FakeNode.prototype,'hidden',{get(){return this.hasAttribute('hidden');},set(v){if(v)this.setAttribute('hidden','');else this.removeAttribute('hidden');}});
// Lightweight DOM integration harness: actual app/modules and event handlers; no browser engine.
const profilePanel=add(main,'div','profile-panel'),profileSummary=add(main,'p','profile-summary');
const search=add(main,'input','faq-search'),faqCategory=add(main,'select','faq-category'),faqContent=add(main,'div','faq-content');
const legacyCategories=add(main,'div','legacy-categories');legacyCategories.className='category-section';
const hero=add(main,'p','hero-persona',{'data-i18n':'hero.description'}),simCopy=add(main,'p','simulation-persona',{'data-i18n':'simulation.description'}),mapCopy=add(main,'p','map-persona',{'data-i18n':'tool.map.description'});
const meta=add(document.documentElement,'meta','description-meta',{name:'description'}),nav=add(main,'nav','desktop-nav');nav.className='desktop-nav';const noScript=add(main,'div','noscript-copy');noScript.className='noscript-note';
const sourceRegistry=add(main,'div','source-registry');
const guideSections={};for(const id of ['start','documents','life','faq','cities']){guideSections[id]=add(main,'section',id);guideSections[id].rect={left:0,top:id==='start'?0:1100,bottom:id==='start'?1000:2100,width:1000,height:1000,right:1000};}
const {quiz:baseQuiz,simulation:baseStory,sources,content:ui,actions:realActions,problems}=await import(moduleURL('migrato/dist/data/content.js'));
const {faq,faqSources}=await import(moduleURL('migrato/dist/data/faq.js'));
const {personas,quizForCategory,simulationForCategory,faqForCategory,mapDescription}=await import(moduleURL('migrato/dist/data/personas.js'));
const originalQuiz=JSON.stringify(baseQuiz),originalStory=JSON.stringify(baseStory),sourceIds=new Set(sources.map(s=>s.id));
for(const category of ['student','worker','remote','relocate']){
 const quiz=quizForCategory(category),story=simulationForCategory(category),items=faqForCategory(category,faq);
 assert.equal(quiz.length,12);assert.equal(new Set(quiz.map(q=>q.id)).size,12);assert.equal(story.length,5);
 assert.equal(quiz.find(q=>q.id==='q8').correct,1);
 for(const id of quiz.find(q=>q.id==='q8').sourceIds)assert.ok(sourceIds.has(id));
 const reference=category==='student'?'q8':{worker:'q7',remote:'q9',relocate:'q10'}[category];assert.deepEqual(quiz.find(q=>q.id==='q8').explanation,baseQuiz.find(q=>q.id===reference).explanation);
 assert.deepEqual(story.find(s=>s.id==='settle').scene,personas[category].finalScene);
 assert.ok(items.some(item=>item.category==='study')===(category==='student'));
 if(category==='student')assert.ok(items.some(item=>item.category==='student-work'&&item.categoryLabel));else assert.ok(!items.some(item=>item.id==='student-employment'));
 for(const common of ['migration','documents','finance','housing','health','life'])assert.equal(items.filter(item=>item.category===common).length,faq.filter(item=>item.category===common).length);
 for(const lang of ['ru','kk','en']){assert.ok(personas[category].hero[lang]);assert.ok(quiz.find(q=>q.id==='q8').question[lang]);assert.ok(story.find(s=>s.id==='settle').recoveryScene[lang]);}
}
assert.equal(JSON.stringify(baseQuiz),originalQuiz);assert.equal(JSON.stringify(baseStory),originalStory);
console.log('PASS pure category data: 4 profiles, 12 questions, category q8, verified explanations/source ids, 5-scene story, FAQ scope, 3 languages, immutable base content.');
try{
 if(process.argv.includes('--bundle')){
  const html=fs.readFileSync('migrato/Migrato.html','utf8'),scripts=[...html.matchAll(/<script\b[^>]*>([\s\S]*?)<\/script\s*>/gi)].map(match=>match[1]).filter(code=>code.trim());
  assert.ok(scripts.length,'The autonomous HTML contains executable inline JavaScript');
  for(const code of scripts)vm.runInThisContext(code,{filename:'Migrato.html:inline-script'});
 }else await import(moduleURL('migrato/dist/app.js'));
}catch(error){console.error(error.name+': '+error.message.replace(/data:text\/javascript;base64,[A-Za-z0-9+/=]+/g,'[compiled module]'));process.exit(1);}
console.log(`App execution: ${process.argv.includes('--bundle')?'actual autonomous HTML inline bundle':'actual source ES module graph'} in lightweight DOM harness.`);
assert.ok(document.getElementById('site-guide'));
const initialToggle=document.querySelector('.site-guide-toggle'),initialBubble=document.getElementById('site-guide-bubble');
assert.equal(initialBubble.hidden,false);assert.equal(initialToggle.getAttribute('aria-expanded'),'true');
assert.equal(document.activeElement===document.body,true,'Automatic welcome must not steal focus');
assert.ok(initialBubble.textContent.includes('Барыс · ваш консультант'));assert.ok(initialBubble.textContent.includes('Я Барыс, ваш консультант'));
const welcomeMotion=animationCalls.find(record=>record.node===initialBubble.querySelector('.site-guide-message'));assert.ok(welcomeMotion);assert.equal(welcomeMotion.options.duration,280);assert.deepEqual(welcomeMotion.keyframes,[{opacity:0,transform:'translateY(5px)'},{opacity:1,transform:'translateY(0)'}]);assert.ok(welcomeMotion.node.textContent.includes('Я Барыс, ваш консультант'));
assert.equal(document.querySelectorAll('#site-guide').length,1);advance(5000);assert.equal(initialBubble.hidden,false);
document.querySelector('.guide-close').click();window.dispatchEvent({type:'scroll'});assert.equal(initialBubble.hidden,true);
initialToggle.click();initialBubble.querySelector('.button').click();assert.equal(initialBubble.hidden,true);assert.equal(dialog.open,false);assert.equal(document.activeElement.id,'onboard-category');
for(const tool of ['simulation','route','quiz','calendar','navigator','map','checklist','budget','rental','phrases']){window.openTool(tool);assert.equal(dialog.open,false);assert.ok(document.getElementById('onboard-category'));}
const allSourceIds=new Set([...sources,...faqSources].map(source=>source.id));
for(const item of faq){for(const id of item.sourceIds||[])assert.ok(allSourceIds.has(id),item.id+': unknown source '+id);for(const lang of ['ru','kk','en'])for(const field of ['question','answer','authority','ask'])assert.ok(item[field][lang]);}
for(const source of [...sources,...faqSources]){assert.ok(sourceRegistry.textContent.includes(source.checked));assert.ok(sourceRegistry.textContent.includes(source.title.ru));}
console.log('PASS initial app: welcome opens automatically with full consultant name and an actionable profile CTA without focus theft or timed dismissal; 10 tools require profile; combined source registry and FAQ references/languages are complete.');
const saved=()=>JSON.parse(localStorage.getItem('migrato-progress-v1'));
const fill=(id,value,type='change')=>{const n=document.getElementById(id);n.value=value;n.dispatchEvent({type,bubbles:true});};
function profile(category,city='astana',citizenship='ru'){
 if(dialog.open)close.click();
 if(profilePanel.querySelector('.profile-active'))profilePanel.querySelector('button').click();
 fill('onboard-category',category);fill('onboard-city',city);fill('onboard-citizen',citizenship);profilePanel.querySelector('form').dispatchEvent({type:'submit',bubbles:true});
}
assert.equal(legacyCategories.hidden,false);
profile('student','almaty','ru');
assert.equal(legacyCategories.hidden,true);assert.equal(hero.textContent,personas.student.hero.ru);assert.ok(faqContent.querySelector('#faq-question-university-host'));assert.ok(faqContent.querySelector('#faq-question-student-employment'));assert.ok(faqCategory.querySelectorAll('option').some(o=>o.value==='study'));assert.ok(faqCategory.querySelectorAll('option').some(o=>o.value==='student-work'));
window.openTool('quiz');content.querySelectorAll('.option-button')[0].click();close.click();window.openTool('simulation');content.querySelectorAll('.option-button')[0].click();close.click();window.openTool('checklist');const realTask=content.querySelector('input[type="checkbox"]');realTask.checked=true;realTask.dispatchEvent({type:'change',bubbles:true});close.click();assert.equal(saved().actionDone.notify,true);assert.ok(saved().quiz.answers.q1!==undefined);assert.ok(saved().simulation.choices.arrival!==undefined);
for(const category of ['worker','remote','relocate']){
 profile(category);
 assert.equal(saved().learningCategory,category);assert.deepEqual(saved().quiz.answers,{});assert.deepEqual(saved().simulation.choices,{});assert.equal(saved().actionDone.notify,true);assert.equal(saved().route.ready,false);assert.equal(saved().calendar.ready,false);
 assert.equal(legacyCategories.hidden,true);assert.ok(!faqContent.querySelector('#faq-question-university-host'));assert.ok(!faqContent.querySelector('#faq-question-student-employment'));assert.ok(!faqCategory.querySelectorAll('option').some(o=>o.value==='study'));
 for(const lang of ['ru','kk','en']){language.focus();fill('language-select',lang);assert.equal(document.activeElement,language);assert.equal(hero.textContent,personas[category].hero[lang]);assert.equal(simCopy.textContent,personas[category].description[lang]);assert.equal(mapCopy.textContent,mapDescription('astana')[lang]);assert.equal(meta.getAttribute('content'),ui[lang]['page.description']);assert.equal(nav.getAttribute('aria-label'),ui[lang]['access.mainNav']);assert.equal(noScript.textContent,ui[lang]['access.noscript']);}
}
profile('worker','astana','ru');fill('language-select','ru');window.openTool('quiz');let options=()=>content.querySelectorAll('.option-button');for(let i=0;i<7;i++){options()[quizForCategory('worker')[i].correct].click();content.querySelector('.result-box button').click();}assert.equal(content.querySelector('h3').textContent,quizForCategory('worker')[7].question.ru);close.click();
window.openTool('route');fill('profile-days','60','input');content.querySelector('form').dispatchEvent({type:'submit',bubbles:true});assert.equal(saved().route.ready,true);close.click();window.openTool('calendar');fill('calendar-arrival','2026-11-11','input');fill('profile-days','60','input');content.querySelector('form').dispatchEvent({type:'submit',bubbles:true});assert.equal(saved().calendar.ready,true);close.click();
const previousQuiz=JSON.stringify(saved().quiz);profile('worker','shymkent','ua');assert.equal(JSON.stringify(saved().quiz),previousQuiz);assert.equal(saved().actionDone.notify,true);assert.equal(saved().route.citizenship,'ua');assert.equal(saved().calendar.citizenship,'ua');assert.equal(saved().map.city,'shymkent');assert.equal(saved().route.ready,false);assert.equal(saved().calendar.ready,false);
console.log('PASS actual app handlers: hidden legacy categories; persona hero/simulation/map copy; localized metadata/aria/noscript; student and non-student FAQ topics; worker q8 screen; category resets only learning state; city/country changes invalidate route/calendar while preserving learning and real task marks.');
const {createSimulationState}=await import(moduleURL('migrato/dist/modules/learning.js'));const source=fs.readFileSync('migrato/dist/app.js','utf8'),pure=source.slice(source.indexOf('function defaults()'),source.indexOf('let state=defaults()'));
const {restore}=new Function('createSimulationState','categories','profileCities','profileCitizenships',pure+';return {restore};')(createSimulationState,new Set(['student','worker','remote','relocate']),new Set(['astana','almaty','shymkent']),new Set(['am','az','by','kg','md','ru','tj','tm','ua','uz','other']));
const consistent=saved();assert.deepEqual(restore(consistent).quiz,consistent.quiz);const stale={...consistent,learningCategory:'student'};assert.deepEqual(restore(stale).quiz,{index:0,answers:{}});assert.equal(restore(stale).actionDone.notify,true);const wrongCountry=structuredClone(consistent);wrongCountry.route.ready=true;wrongCountry.calendar.ready=true;wrongCountry.route.citizenship='ru';assert.equal(restore(wrongCountry).route.ready,false);assert.equal(restore(wrongCountry).route.citizenship,'ua');
console.log('PASS restore: same-category answers retained; mismatched learning context reset without touching real actions; stale questionnaire citizenship corrected and result invalidated.');
if(dialog.open)close.click();
fill('language-select','ru');
const toggle=document.querySelector('.site-guide-toggle'),bubble=document.getElementById('site-guide-bubble');
if(!bubble.hidden)document.querySelector('.guide-close').click();
toggle.click();assert.equal(bubble.hidden,false);assert.equal(toggle.getAttribute('aria-expanded'),'true');
document.querySelector('.guide-close').click();assert.equal(bubble.hidden,true);assert.equal(document.activeElement,toggle);
function visibleSection(id){for(const section of Object.values(guideSections))section.rect={left:0,top:-1100,bottom:-100,width:1000,height:1000,right:1000};guideSections[id].rect={left:0,top:0,bottom:900,width:1000,height:900,right:1000};window.dispatchEvent({type:'scroll'});}
const sectionTitles={start:'Начнём с вашего пути',documents:'Документы по шагам',life:'Обустроимся без спешки',faq:'Найдём понятный ответ',cities:'Выберем нужную организацию'};
for(const section of ['documents','life','faq','cities','start']){
 search.focus();visibleSection(section);assert.equal(bubble.hidden,false);assert.equal(document.activeElement===search,true,'Section advice must not steal focus');assert.equal(bubble.querySelector('h3').textContent,sectionTitles[section]);
 document.querySelector('.guide-close').click();window.dispatchEvent({type:'scroll'});assert.equal(bubble.hidden,true);fill('language-select','en');assert.equal(bubble.hidden,true);fill('language-select','ru');assert.equal(bubble.hidden,true);
}
visibleSection('faq');assert.equal(bubble.querySelector('h3').textContent,'Найдём понятный ответ');
search.focus();for(const query of ['И','ИИ','ИИН']){fill('faq-search',query,'input');advance(100);assert.equal(search.value,query);assert.equal(document.activeElement,search);assert.equal(document.getElementById('site-guide').dataset.event,'section');}
advance(399);assert.equal(document.getElementById('site-guide').dataset.event,'section');advance(1);assert.equal(document.getElementById('site-guide').dataset.event,'faq-search');
assert.equal(document.querySelector('.site-guide-bubble h3').textContent,'Я посмотрел результаты поиска');assert.equal(search.value,'ИИН');assert.equal(document.activeElement,search);
document.querySelector('.site-guide-bubble .button').click();assert.equal(document.activeElement,search);assert.equal(bubble.hidden,true);assert.equal(guideSections.faq.lastScrollIntoView.block,'start');
toggle.click();const pause=document.querySelector('.guide-motion');pause.focus();pause.click();assert.equal(document.documentElement.dataset.motion,'paused');assert.equal(localStorage.getItem('migrato-motion'),'paused');
console.log('PASS guide/FAQ DOM: all 5 sections reopen useful contextual advice without focus theft; dismiss survives same-section scroll and language changes; search waits 500ms after the final keystroke, preserves typing/focus; FAQ CTA and animation preferences work.');
assert.equal(document.activeElement,document.querySelector('.guide-motion'));

// Deterministic timers model only the standard setTimeout/clearTimeout API;
// actual application handlers decide when and whether a celebration is shown.
const celebration=()=>document.querySelector('.journey-celebration');
const celebrationShows=()=>modalCalls.filter(node=>node.className==='journey-celebration').length;
const mark=(input,checked)=>{input.focus();input.checked=checked;input.dispatchEvent({type:'input',bubbles:true});input.dispatchEvent({type:'change',bubbles:true});};
const reset=add(main,'button','qa-reset',{'data-action':'reset-progress'});
document.querySelector('.guide-motion').click();assert.equal(document.documentElement.dataset.motion,'on');
setReduced(false);
reset.click();profile('worker','astana','ru');
assert.equal(saved().route.celebrated,false);assert.deepEqual(saved().actionDone,{});
window.openTool('route',launches.route);fill('profile-days','60','input');content.querySelector('form').dispatchEvent({type:'submit',bubbles:true});
assert.equal(saved().route.ready,true);assert.ok(content.querySelector('[data-journey]'));
assert.equal(caughtErrors.length,0,'No caught tool initialization errors');
const points=[['arrival',120,95],['documents',380,225],['housing',140,380],['work',380,530],['life',260,700]];
const routeSvg=content.querySelector('.journey-map-svg'),runner=content.querySelector('.journey-runner');
assert.equal(runner.parentNode,routeSvg);assert.equal(routeSvg.getAttribute('viewBox'),'0 0 520 780');
assert.equal(routeSvg.querySelector('polyline').getAttribute('points'),points.map(([,x,y])=>`${x},${y}`).join(' '));
// The nested 320x400 mascot scales 1/4: its feet (160,376) plus x/y land at (0,0).
assert.match(runner.innerHTML,/viewBox="0 0 320 400"/);
assert.match(runner.innerHTML,/x="-40" y="-94" width="80" height="100"/);
assert.equal(160*80/320-40,0);assert.equal(376*100/400-94,0);
for(const [id,x,y]of points){
 const control=document.getElementById(`journey-stop-${id}`),card=document.getElementById(`journey-card-${id}`);
 control.click();assert.equal(runner.style.transform,`translate(${x}px, ${y}px)`);
 assert.equal(control.getAttribute('aria-current'),'step');assert.equal(control.getAttribute('aria-expanded'),'true');assert.equal(card.open,true);assert.equal(document.activeElement,card.querySelector('summary'));
 assert.equal(content.querySelectorAll('.journey-card').filter(n=>n.open).length,1);assert.deepEqual(saved().actionDone,{});
 // Browsers queue native toggle events after programmatic open changes.
 for(const queued of content.querySelectorAll('.journey-card'))queued.dispatchEvent({type:'toggle',bubbles:false});
 assert.equal(runner.style.transform,`translate(${x}px, ${y}px)`);assert.deepEqual(saved().actionDone,{});
}
const arrivalCard=document.getElementById('journey-card-arrival'),lifeCard=document.getElementById('journey-card-life');
arrivalCard.open=true;arrivalCard.dispatchEvent({type:'toggle',bubbles:false});
assert.equal(lifeCard.open,false);assert.equal(runner.style.transform,'translate(120px, 95px)');
lifeCard.dispatchEvent({type:'toggle',bubbles:false});assert.equal(runner.style.transform,'translate(120px, 95px)');
assert.deepEqual(saved().actionDone,{});
console.log('PASS route handlers: ready route renders without caught errors; all 5 stage controls and native queued toggle handlers select exact path coordinates, preserve every real task mark, and focus the selected summary. SVG feet and path share coordinates.');

const routeChecks=content.querySelectorAll('.journey-card input[type="checkbox"]');assert.equal(routeChecks.length,9);
const showCount=celebrationShows();
routeChecks.forEach((input,index)=>{mark(input,true);assert.equal(celebration(),null);assert.equal(saved().route.celebrated,false);});
assert.equal(Object.values(saved().actionDone).filter(Boolean).length,9);assert.equal(runner.style.transform,'translate(260px, 700px)');assert.equal(content.querySelector('.journey-finish').hidden,false);
assert.equal(celebration(),null);advance(849);assert.equal(celebration(),null);advance(1);
assert.equal(celebrationShows(),showCount+1);assert.equal(saved().route.celebrated,true);assert.equal(celebration().open,true);assert.equal(document.activeElement,celebration().querySelector('.celebration-return'));
assert.equal(celebration().querySelectorAll('.firework-burst').length,5);assert.equal(celebration().querySelectorAll('.firework-burst i').length,50);
assert.ok(celebration().textContent.includes('Вы отметили действия как выполненные.'));
celebration().querySelector('.celebration-return').click();assert.equal(celebration(),null);assert.equal(document.activeElement,routeChecks.at(-1));assert.equal(dialog.open,true);
mark(routeChecks[0],false);assert.equal(content.querySelector('.journey-finish').hidden,true);assert.equal(saved().route.celebrated,false);mark(routeChecks[0],true);advance(1000);assert.equal(celebrationShows(),showCount+2);assert.equal(celebration().open,true);celebration().querySelector('.celebration-return').click();assert.equal(document.activeElement,routeChecks[0]);
close.click();assert.equal(document.activeElement,launches.route);window.openTool('route',launches.route);advance(1000);assert.equal(celebration(),null);
assert.equal(content.querySelectorAll('.journey-card input[type="checkbox"]').filter(input=>input.checked).length,9);
const celebrationTitles={ru:'Поздравляем! Вы у Байтерека!',kk:'Құттықтаймыз! Сіз Бәйтерекке жеттіңіз!',en:'Congratulations! You reached Baiterek!'};
for(const lang of ['ru','kk','en']){
 fill('tool-language',lang);assert.equal(celebration(),null);assert.equal(content.querySelector('.journey-finish').hidden,false);
 const repeat=content.querySelector('.journey-finish button');repeat.focus();repeat.click();
 assert.equal(celebration().querySelector('h2').textContent,celebrationTitles[lang]);assert.equal(document.activeElement,celebration().querySelector('.celebration-return'));
 if(lang==='kk'){
  // The native cancel default action closes an unprevented Escape event.
  const active=celebration(),event={type:'cancel',bubbles:false,cancelable:true};active.dispatchEvent(event);if(!event.defaultPrevented)active.close();
 }else celebration().querySelector('.celebration-close').click();
 assert.equal(celebration(),null);assert.equal(document.activeElement,repeat);assert.equal(dialog.open,true);
}
assert.equal(celebrationShows(),showCount+5);assert.equal(saved().route.celebrated,true);
close.click();fill('language-select','ru');window.openTool('checklist');assert.equal(content.querySelectorAll('input[type="checkbox"]').filter(input=>input.checked).length,9);assert.equal(celebration(),null);close.click();
console.log('PASS actual completion handlers: only ninth real checkbox schedules one automatic congratulations after 850ms and only shown dialogs persist celebrated; close restores checkbox focus; uncheck starts a fresh completion cycle; reopening and language changes never replay automatically; manual replay works in RU/KK/EN, Escape/close returns focus; checklist shares all 9 marks.');

// Closing the parent tool cancels the pending native modal.
reset.click();profile('remote');window.openTool('route',launches.route);fill('profile-days','60','input');content.querySelector('form').dispatchEvent({type:'submit',bubbles:true});
const pendingChecks=content.querySelectorAll('.journey-card input[type="checkbox"]');
for(const input of pendingChecks)mark(input,true);
assert.equal(celebration(),null);advance(400);mark(pendingChecks.at(-1),false);advance(500);assert.equal(celebration(),null);assert.equal(saved().route.celebrated,false);assert.equal(content.querySelector('.journey-finish').hidden,true);
mark(pendingChecks.at(-1),true);advance(400);close.click();advance(1000);assert.equal(celebration(),null);assert.equal(saved().route.celebrated,false);
// Changing language while a pending celebration exists rerenders route controls.
window.openTool('route',launches.route);let pendingLast=content.querySelectorAll('.journey-card input[type="checkbox"]').at(-1);mark(pendingLast,false);mark(pendingLast,true);advance(400);
document.getElementById('tool-language').focus();fill('tool-language','en');const translatedLanguage=document.getElementById('tool-language');assert.equal(document.activeElement,translatedLanguage);advance(450);
assert.equal(celebration().querySelector('h2').textContent,celebrationTitles.en);assert.equal(saved().route.celebrated,true);celebration().querySelector('.celebration-return').click();assert.equal(document.activeElement===document.getElementById('journey-stop-life'),true,'Detached pre-translation checkbox falls back to the current Baiterek stage control');assert.equal(dialog.open,true);close.click();fill('language-select','ru');
// Completion from the common checklist invokes the same hook immediately.
reset.click();profile('student');window.openTool('checklist');
const sharedChecks=content.querySelectorAll('input[type="checkbox"]');assert.equal(sharedChecks.length,9);
for(const input of sharedChecks.slice(0,8))mark(input,true);assert.equal(celebration(),null);
const sharedLast=sharedChecks.at(-1);mark(sharedLast,true);assert.equal(celebration()?.open,true);celebration().querySelector('.celebration-return').click();assert.equal(document.activeElement,sharedLast);close.click();
console.log('PASS pending/shared completion: unchecking during 850ms cancels the popup and leaves celebration unrecorded; closing route cancels pending congratulations; a pending language switch shows translated congratulations and close returns focus to the connected Baiterek control; ninth checklist mark uses the shared completion hook.');

// The active consultant runs the actual source/bundle handlers in every tool.
reset.click();profile('worker');
const toolNames=['simulation','route','quiz','calendar','navigator','map','checklist','budget','rental','phrases'];
const semanticRU={simulation:/Шаг 1.*Примите решение/,route:/Уточните цель.*Составить маршрут/,quiz:/Вопрос 1 из 12.*Выберите один вариант/,calendar:/дату въезда.*планируемый срок/,navigator:/выберите затруднение.*уточняющий вопрос/,map:/город и тип организации.*точный адрес/,checklist:/следующий незавершённый пункт.*реального действия/,budget:/суммы в два варианта.*депозит/,rental:/условия учебного договора.*Проверить выбор/,phrases:/ситуацию и язык обращения.*копированием или печатью/};
const names={ru:'Барыс · ваш консультант',kk:'Барыс · кеңесшіңіз',en:'Barys · your consultant'},messagesByLanguage={};
for(const lang of ['ru','kk','en']){
 fill('language-select',lang);const texts=[];
 for(const tool of toolNames){
  window.openTool(tool);assert.equal(dialog.open,true);assert.equal(content.querySelectorAll('.barys-guide').length,1);
  const greeting=content.querySelector('.barys-greeting');assert.ok(greeting.textContent.length>50);assert.equal(greeting.getAttribute('aria-live'),'polite');assert.equal(greeting.getAttribute('aria-atomic'),'true');
  assert.equal(content.querySelector('.barys-name').textContent,names[lang]);assert.equal(document.activeElement.id,'tool-title');assert.equal(document.getElementById('site-guide').getAttribute('aria-label'),names[lang]);
  if(lang==='ru')assert.match(greeting.textContent,semanticRU[tool]);texts.push(greeting.textContent);
  for(const event of ['change','input','click'])assert.equal(content.events[event].length,1,`Only one current helper ${event} listener after repeated renders`);
  close.click();
 }
 assert.equal(new Set(texts).size,10,'Every tool needs a distinct actionable instruction');messagesByLanguage[lang]=texts;
}
for(let index=0;index<10;index++){assert.notEqual(messagesByLanguage.ru[index],messagesByLanguage.kk[index]);assert.notEqual(messagesByLanguage.ru[index],messagesByLanguage.en[index]);}
fill('language-select','ru');
console.log('PASS active consultant: 10 distinct actionable tool instructions in RU/KK/EN, full consultant identity, polite status, one helper and one listener per event after repeated mounts; opening each tool focuses its title.');

window.openTool('quiz');let guideText=()=>content.querySelector('.barys-greeting').textContent;
assert.match(guideText(),/Вопрос 1 из 12/);let currentQuestion=quizForCategory('worker')[0];content.querySelectorAll('.option-button')[currentQuestion.correct].click();assert.match(guideText(),/ответ верный/);assert.ok(guideText().includes(currentQuestion.explanation.ru));assert.equal(content.querySelector('.barys-character').dataset.mood,'success');
content.querySelector('.result-box button').click();assert.match(guideText(),/Вопрос 2 из 12/);currentQuestion=quizForCategory('worker')[1];content.querySelectorAll('.option-button')[(currentQuestion.correct+1)%currentQuestion.options.length].click();assert.match(guideText(),/нужен другой ответ/);assert.ok(guideText().includes(currentQuestion.explanation.ru));assert.equal(content.querySelector('.barys-character').dataset.mood,'caution');close.click();
window.openTool('simulation');assert.match(guideText(),/Шаг 1/);const scene=simulationForCategory('worker')[0],safeChoice=scene.choices.findIndex(choice=>choice.risk===false||choice.good===true||choice.safe===true);content.querySelectorAll('.option-button')[safeChoice>=0?safeChoice:0].click();assert.notEqual(guideText(),messagesByLanguage.ru[0]);assert.ok(guideText().includes(scene.choices[safeChoice>=0?safeChoice:0].feedback.ru));assert.deepEqual(saved().actionDone,{});close.click();
window.openTool('navigator');content.querySelector('.option-button').click();assert.ok(guideText().includes(problems[0].question.ru));content.querySelector('.option-button').click();assert.ok(guideText().includes(problems[0].options[0].body.ru));assert.deepEqual(saved().actionDone,{});close.click();
console.log('PASS decision feedback: quiz correct/wrong explanations and question number update with mood; simulation reacts to its actual decision without completing real actions; navigator clarifies the selected problem and gives its actual next-step answer.');

window.openTool('checklist');const taskChecks=content.querySelectorAll('input[type="checkbox"]');
const expectedNotify=realActions.find(action=>action.id==='notify'),expectedNext=realActions.find(action=>action.id==='stay');
mark(taskChecks[0],true);const checkedMessage=guideText();assert.ok(checkedMessage.includes(`Вы отметили «${expectedNotify.title.ru}»`));assert.ok(checkedMessage.includes(`Следующий пункт: ${expectedNext.title.ru}`));assert.equal(document.activeElement===taskChecks[0],true);
advance(500);assert.equal(guideText(),checkedMessage,'Bubbling input/change and 500ms debounce must preserve the specific checkbox reply');assert.equal(document.activeElement===taskChecks[0],true);
mark(taskChecks[0],false);const uncheckedMessage=guideText();assert.ok(uncheckedMessage.includes('Вы сняли отметку с'));assert.ok(uncheckedMessage.includes(`Следующий пункт: ${expectedNotify.title.ru}`));advance(500);assert.equal(guideText(),uncheckedMessage);close.click();
window.openTool('route');fill('profile-days','60','input');content.querySelector('form').dispatchEvent({type:'submit',bubbles:true});
const currentMap=content.querySelector('.journey-map-wrap'),currentObserver=resizeObservers.find(observer=>observer.targets.has(currentMap));assert.ok(currentObserver);
const mapMode=content.querySelector('.journey-map-mode'),modeMarks=structuredClone(saved().actionDone),modeRunner=content.querySelector('.journey-runner').style.transform;
assert.equal(mapMode.textContent,'Компактный вид');assert.equal(mapMode.getAttribute('aria-expanded'),'true');assert.ok(!currentMap.className.includes('is-compact'));
port.clientHeight=400;currentMap.scrollHeight=800;currentObserver.trigger();assert.ok(!currentMap.className.includes('is-compact'),'Short height must never shrink the map automatically');assert.ok(currentMap.className.includes('is-unpinned'));assert.equal(content.querySelector('[data-journey]').style.getPropertyValue('--journey-sticky-clearance'),'16px');
mapMode.focus();mapMode.click();assert.ok(currentMap.className.includes('is-compact'));assert.equal(mapMode.textContent,'Развернуть карту');assert.equal(mapMode.getAttribute('aria-expanded'),'false');assert.equal(document.activeElement,mapMode);assert.deepEqual(saved().actionDone,modeMarks);assert.equal(content.querySelector('.journey-runner').style.transform,modeRunner);
currentMap.scrollHeight=250;currentObserver.trigger();assert.ok(!currentMap.className.includes('is-unpinned'));
port.clientHeight=0;currentObserver.trigger();assert.ok(currentMap.className.includes('is-compact'));
mapMode.click();assert.ok(!currentMap.className.includes('is-compact'));assert.equal(mapMode.getAttribute('aria-expanded'),'true');
port.clientHeight=780;currentMap.scrollHeight=300;currentObserver.trigger();assert.ok(!currentMap.className.includes('is-compact'));assert.ok(!currentMap.className.includes('is-unpinned'));
const routeCSS=process.argv.includes('--bundle')?fs.readFileSync('migrato/Migrato.html','utf8'):fs.readFileSync('migrato/dist/journey.css','utf8');
assert.match(routeCSS,/\.journey-map\s*\{[^}]*width:min\(100%,460px\)/);assert.ok(!routeCSS.includes('--journey-map-max-height'));
const docStage=document.getElementById('journey-stop-documents');docStage.click();assert.match(guideText(),/Выбор этапа не отмечает действия выполненными/);assert.equal(saved().actionDone.notify,false);
const routeFirst=content.querySelector('.journey-card input[type="checkbox"]');mark(routeFirst,true);const routeReply=guideText();advance(500);assert.equal(guideText(),routeReply);assert.ok(routeReply.includes(`Следующий пункт: ${expectedNext.title.ru}`));close.click();assert.equal(currentObserver.targets.size,0,'Closing tool disconnects its ResizeObserver');
console.log('PASS action feedback: checkbox input→change bubbling plus 500ms preserves the concrete marked/unmarked reply and first unfinished relevant task; stage selection is informational. ResizeObserver guard handles real positive/zero dimensions and disconnects on close (not a visual layout test).');

fill('faq-search','','input');advance(500);const faqItem=faqContent.querySelector('.faq-item'),faqData=faq.find(item=>item.id===faqItem.dataset.faqId),faqSummary=faqItem.querySelector('summary');
faqSummary.focus();faqItem.open=true;faqItem.dispatchEvent({type:'toggle',bubbles:false});assert.equal(document.getElementById('site-guide').dataset.event,'faq-answer');assert.ok(bubble.textContent.includes(faqData.steps[0].ru));assert.ok(bubble.textContent.includes(faqData.authority.ru));advance(500);assert.equal(document.getElementById('site-guide').dataset.event,'faq-answer');assert.equal(document.activeElement===faqSummary,true);
fill('faq-search','zz-no-matches-qa','input');advance(500);assert.ok(bubble.textContent.includes('Совпадений нет'));assert.equal(faqContent.querySelectorAll('.faq-item').length,0);fill('faq-search','','input');advance(500);assert.ok(bubble.textContent.includes('Найдено ответов:'));assert.equal(search.value,'');
for(const [section,tool]of [['documents','route'],['life','checklist'],['cities','map'],['start','route']]){
 visibleSection(section);const cta=bubble.querySelector('.button');cta.focus();cta.click();assert.equal(dialog.open,true);assert.equal(bubble.hidden,true);
 if(tool==='route')assert.ok(content.querySelector('[data-journey]'));else if(tool==='checklist')assert.equal(content.querySelectorAll('input[type="checkbox"]').length,9);else assert.ok(content.querySelector('.places-directory'));
 close.click();
}
visibleSection('faq');
console.log('PASS FAQ/section actions: opening an answer gives its first real step and authority via capture-phase toggle without stealing focus; zero-result and clear-search guidance are useful; documents/life/cities/start CTAs open their actual route/checklist/map targets.');

window.openTool('budget');const modalPause=content.querySelector('.barys-motion-toggle');modalPause.focus();modalPause.click();await Promise.resolve();
assert.equal(document.documentElement.dataset.motion,'paused');assert.equal(modalPause.getAttribute('aria-pressed'),'true');close.click();
assert.equal(document.querySelector('.guide-motion').getAttribute('aria-pressed'),'true','Global pause is reflected by the main consultant after returning from a tool');
document.querySelector('.guide-motion').click();assert.equal(document.documentElement.dataset.motion,'on');

const siteMessage=bubble.querySelector('.site-guide-message'),messageAnimations=()=>animationCalls.filter(record=>record.node===siteMessage);
const unchangedCount=messageAnimations().length;fill('language-select','ru');assert.equal(messageAnimations().length,unchangedCount,'Unchanged text must not restart its reveal effect');
visibleSection('documents');assert.equal(messageAnimations().length,unchangedCount+1);const activeTextAnimation=messageAnimations().at(-1);assert.equal(activeTextAnimation.playState,'running');
setReduced(true);assert.equal(activeTextAnimation.cancelled,true);const beforeReduced=animationCalls.length;visibleSection('life');assert.equal(animationCalls.length,beforeReduced);assert.ok(siteMessage.textContent.includes('сравнить свои расходы'));
setReduced(false);visibleSection('faq');const beforePaused=animationCalls.length;document.querySelector('.guide-motion').click();await Promise.resolve();assert.equal(messageAnimations().at(-1).cancelled,true);visibleSection('cities');assert.equal(animationCalls.length,beforePaused);
document.querySelector('.guide-motion').click();assert.equal(document.documentElement.dataset.motion,'on');
window.openTool('budget');const unchangedModalCount=animationCalls.length;content.dispatchEvent({type:'change',bubbles:true});content.dispatchEvent({type:'input',bubbles:true});advance(500);assert.equal(animationCalls.length,unchangedModalCount,'Generic unchanged tool input must not restart message animation');close.click();
setReduced(true);const reducedModalCount=animationCalls.length;window.openTool('calendar');assert.equal(animationCalls.length,reducedModalCount);assert.ok(content.querySelector('.barys-greeting').textContent.includes('дату въезда'));close.click();setReduced(false);visibleSection('faq');
console.log('PASS text motion: full message is present immediately; changed messages use 280ms opacity/translate only; unchanged main/tool text does not restart; system reduce/manual pause cancel active effects and disable new effects; returning from modal pause synchronizes the main control.');

fill('faq-category','all');fill('faq-search','счет','input');const withoutYo=faqContent.querySelectorAll('[data-faq-id]').map(n=>n.dataset.faqId);assert.ok(withoutYo.length>0);
fill('faq-search','счёт','input');assert.deepEqual(faqContent.querySelectorAll('[data-faq-id]').map(n=>n.dataset.faqId),withoutYo);
const guideToggle=document.querySelector('.site-guide-toggle');
setReduced(true);
if(document.getElementById('site-guide-bubble').hidden)guideToggle.click();document.querySelector('.site-guide-bubble .button').click();assert.ok(['auto','instant'].includes(guideSections.faq.lastScrollIntoView.behavior));
setReduced(false);
guideToggle.click();document.querySelector('.site-guide-bubble .button').click();assert.equal(guideSections.faq.lastScrollIntoView.behavior,'smooth');
guideToggle.click();document.querySelector('.guide-motion').focus();document.querySelector('.guide-motion').click();assert.equal(document.activeElement,document.querySelector('.guide-motion'));
document.querySelector('.site-guide-bubble .button').click();assert.ok(['auto','instant'].includes(guideSections.faq.lastScrollIntoView.behavior));assert.equal(document.activeElement,search);
if(dialog.open)close.click();
const hospitalEntry=document.createElement('button');hospitalEntry.dataset.placeType='medical';
window.openTool('map',hospitalEntry);
assert.ok(content.querySelector('.medical-links'));assert.equal(content.querySelector('.geomap-viewport'),null);assert.ok(guideText().includes('2ГИС'));
const {places:allPlaces}=await import(moduleURL('migrato/dist/data/content.js'));
for(const city of ['astana','almaty','shymkent']){
 const selector=document.getElementById('map-city');selector.focus();fill('map-city',city);
 assert.equal(document.activeElement,selector);assert.equal(content.querySelectorAll('[data-hospital]').length,1);
 const hospital=allPlaces.find(place=>place.city===city&&place.type==='medical'),link=content.querySelector('.medical-2gis-link');
 const url=new URL(link.getAttribute('href'));assert.equal(url.origin,'https://2gis.kz');assert.equal(url.pathname.split('/')[1],city);
 assert.ok(decodeURIComponent(url.pathname).includes(hospital.name.ru));assert.ok(decodeURIComponent(url.pathname).includes(hospital.address.ru));
 assert.equal(link.getAttribute('target'),'_blank');assert.ok(link.getAttribute('rel').includes('noopener'));assert.ok(content.querySelector('.medical-official'));
 assert.equal(content.querySelector('.geomap-viewport'),null);assert.equal(content.querySelectorAll('img').length,0);
}
fill('map-city','all');assert.equal(content.querySelectorAll('[data-hospital]').length,3);
for(const lang of ['ru','kk','en']){fill('tool-language',lang);assert.ok(content.querySelector('.medical-links'));assert.equal(content.querySelectorAll('.medical-2gis-link').length,3);assert.equal(content.querySelector('.barys-name').textContent,{ru:'Барыс · ваш консультант',kk:'Барыс · кеңесшіңіз',en:'Barys · your consultant'}[lang]);}
fill('tool-language','ru');fill('map-type','bank');assert.ok(content.querySelector('.places-directory'));assert.equal(content.querySelector('.geomap-viewport'),null);assert.equal(content.querySelectorAll('[data-place]').length,3);assert.equal(content.querySelectorAll('.directory-2gis-link').length,3);content.querySelector('.medical-shortcut').click();assert.ok(content.querySelector('.medical-links'));assert.equal(content.querySelector('.geomap-viewport'),null);
for(const city of ['all','astana','almaty','shymkent'])for(const type of ['all','service','migration','bank','medical']){
 const citySelect=document.getElementById('map-city'),typeSelect=document.getElementById('map-type');citySelect.focus();fill('map-city',city);assert.equal(document.activeElement,citySelect);typeSelect.focus();fill('map-type',type);assert.equal(document.activeElement,typeSelect);
 const expected=allPlaces.filter(place=>(city==='all'||place.city===city)&&(type==='all'||place.type===type));assert.equal(content.querySelectorAll('[data-place]').length,expected.length);
 assert.equal(content.querySelector('.geomap-viewport'),null);assert.equal(content.querySelector('.places-directory').querySelector('svg'),null);assert.equal(content.querySelectorAll('img').length,0);
 for(const link of content.querySelectorAll('.directory-2gis-link')){assert.equal(new URL(link.getAttribute('href')).origin,'https://2gis.kz');assert.equal(link.getAttribute('target'),'_blank');}
}
assert.ok(!/Динмухамед|Динмұхамед|Dinmukhamed/.test(document.body.textContent));close.click();
console.log('PASS hospital 2GIS links: direct entry, 3 city filters, exact encoded hospital names/addresses, external safe links and official contacts, no embedded map/image tiles, RU/KK/EN and Barys name, all directory categories without any embedded map.');
const actualCSS=process.argv.includes('--bundle')?fs.readFileSync('migrato/Migrato.html','utf8'):['styles.css','guide.css'].map(file=>fs.readFileSync('migrato/dist/'+file,'utf8')).join('\n');
if(guideSections.faq.lastScrollIntoView.behavior==='auto')assert.match(actualCSS,/html\[data-motion=["']paused["']\]\s*\{[^}]*scroll-behavior\s*:\s*auto/,'auto scrolling needs a manual-pause CSS override of the global smooth rule');
assert.equal(search.value,'счёт');assert.equal(caughtErrors.length,0);
globalThis.setTimeout=nativeSetTimeout;globalThis.clearTimeout=nativeClearTimeout;console.error=originalConsoleError;
console.log('PASS FAQ/helper regressions: счет equals счёт; system reduced motion and saved pause avoid smooth scrolling, ordinary mode uses smooth; refreshed pause control retains focus and FAQ typing survives.');
console.log('DOM harness only. Browser layout, native accessibility behaviour and visual QA were not performed.');
